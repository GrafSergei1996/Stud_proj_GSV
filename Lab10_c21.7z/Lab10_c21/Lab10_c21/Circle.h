#pragma once
#include"Shape.h"
//#include"List.h"
#include<iostream>
#include<fstream>
class Circle:public Shape
{
	//friend class Node;
	friend class List;
	int cx;
	int cy;
	int rad;
	//std::ostream& operator << (std::ostream&);
	//std::istream& operator >> (std::istream&);
	virtual bool operator == (const Shape&) const;
	virtual bool operator > (const Shape&) const;
	virtual bool operator < (const Shape&) const;
	virtual std::ostream& operator << (std::ostream&);
	virtual std::ofstream& operator << (std::ofstream&);
	virtual std::ifstream& operator >> (std::ifstream&);
	virtual double Square();
public:
	Circle();
	Circle(Color, int, int, int);
	Circle(const Shape&);
};