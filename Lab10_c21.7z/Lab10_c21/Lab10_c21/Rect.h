#pragma once
#include"Shape.h"
//#include"List.h"
#include<iostream>
#include<fstream>
class Rect :public Shape
{
	//friend class Node;
	friend class List;
	int rleft;
	int rright;
	int rtop;
	int rbot;
	//std::ostream& operator << (std::ostream&);
	//std::istream& operator >> (std::istream&);
	virtual bool operator == (const Shape&) const;
	virtual bool operator > (const Shape&) const;
	
	virtual std::ostream& operator << (std::ostream&);
	virtual std::ofstream& operator << (std::ofstream&);
	virtual std::ifstream& operator >> (std::ifstream&);
	virtual double Square() const;
public:	
	Rect();
	Rect(Color, int, int, int, int);
	Rect(const Shape&);
	virtual bool operator < (const Shape&) const;
};