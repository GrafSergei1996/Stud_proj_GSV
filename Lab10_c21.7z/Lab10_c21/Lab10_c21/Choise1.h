#pragma once
#include <iostream>
#include <vector>
#include <list>
#include <set>
#include <map>
#include <algorithm>
#include <tchar.h>
#include "Point.h"
#include<iterator>
using namespace std;
template <typename T, typename TT> class Changer
{
	T t;
	TT& tt;
public:
	Changer(const T t1, TT& tt1) :t(t1),tt(tt1) {};
	inline void operator () (T& t2)
	{
		typename TT::iterator it1 = find(tt.begin(),tt.end(),t2);
		tt.erase(it1);
		tt.insert(tt.begin(), t);
	}
};

template <typename T, typename TT> class ChangerMap
{
	T t;
	TT& tt;
public:
	ChangerMap(const T t1, TT& tt1) :t(t1), tt(tt1) {};
	inline TT& operator () (const T& t2)
	{
		typename TT::iterator it1 = tt.find(t2.first);
		//it1->first = t.first;
		(*it1).second = t.second;
		//tt.insert(tt.begin(), t);
		//tt.erase(it1);
		return tt;
	}
};

template <typename T, typename TT> inline ostream& operator << (ostream& out, pair<T, TT> p) 
{
	out << p.first << '-' << p.second << '\n';
	return out;
}

template <typename T, typename TT> inline bool operator == (pair<T, TT> p1, TT p2)
{
	return ((p1.second) == p2);
}

template <typename T, typename TT> inline bool operator < (pair<T, TT> p1, pair<T, TT> p2)
{
	return ((p1.second) < (p2.second));
}

template <typename T> inline void Prind(const T& t) 
{
	std::cout << t ;
}

template <typename T, typename TT> inline int GetPointtX (pair<T, TT> p)
{
	return p.second.GetPointX();
}

template <typename T, typename TT> inline int GetPointtY(pair<T, TT> p)
{
	return p.second.GetPointY();
}

template <typename T> inline int GetPointtX(T p)
{
	return p.GetPointX();
}

template <typename T> inline int GetPointtY(T p)
{
	return p.GetPointY();
}

template <typename T> class CmpCoord
{
	int n;
	int m;
public:
	CmpCoord(int i1, int i2) :n(i1), m(i2){};
	inline bool operator () (const T& t2)
	{
		return (GetPointtX(t2) >= n)&&(GetPointtX(t2) <= m)&& (GetPointtY(t2) >= n) && (GetPointtY(t2) <= m);
	}
};

template <typename T> inline T Conv(T& t)
{
	if ((t < 'a') && (t >= 'A'))
	{
		return static_cast<T>(t + 'a'-'A');
	}
	else return t;
}

//inline bool operator < (const Rect& r1, const Rect& r2)
//{
//	return r1.operator < (r2);
//}

template <typename T> class CmpChar
{
	char n;
public:
	CmpChar(char i1) :n(i1) {};
	inline bool operator () (const T& t2)
	{
		return (t2[0]== n);
	}
};

template <typename T, typename TT> inline bool Nechot (pair<T, TT> p1)
{
	return p1.second % 2;
}

template <typename T, typename TT> inline bool Chot(pair<T, TT> p1)
{
	return !(p1.second % 2);
}