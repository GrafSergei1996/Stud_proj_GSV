#pragma once
#include <stack>
#include <queue>
#include <deque>
#include <set>
#include <map>
#include <list>
#include <vector>
#include <string>
#include <clocale>
#include <tchar.h>
#include <iostream>


#include "Prin1.h"
template <typename T, class C>
void Prin(C, T);
#include "Prin1.h"


