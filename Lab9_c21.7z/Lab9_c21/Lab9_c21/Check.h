#pragma once
#pragma warning(disable: 4786)

#include <stack>
#include <set>
#include <map>
#include <list>
#include <vector>
#include <string>
#include <clocale>
#include <tchar.h>
#include <iostream>
#include <queue>
template <typename T> void PrintValves(T a);
template <typename T> T& Firstt(std::queue<T>&);//��� ������ 2 �������� 1-� ���� typename std::
template <typename T> const typename T::value_type& Firstt(T& q);// ���� ������ ������� ��� ��������� �����������, ���� vallue_type

//bool Cmp(const char* a, const char* b)
//{
//	return (strcmp(a, b) < 0);
//}
class Cmp 
{
	 const char* t;
public:
	Cmp() : t(nullptr) {};
	Cmp(const char* t1) :t(t1) {};
	Cmp(const Cmp& t1) :t(t1.t) {};
	bool operator () (const char* t1, const char* t2) const
	{
		return (strcmp(t1, t2)+1);
	}
};

template <typename T> bool CmpInt(const T& i1, const T& i2)
{
	return (*i1.first < *i2.first);
}

class Pred_Char
{
	char t;
public:
	//Cmp() : t(nullptr) {};
	Pred_Char(const char t1) :t(t1) {};
	bool operator () (const char* t1) const
	{
		return (t1[0] == t);
	}
};

template<typename T>
inline void PrintValves(T a)
{
	int n = a.size();
	for (size_t i = 0; i < n; i++)
	{
		std::cout << Firstt(a) << '\n';
		a.pop();
	}
}

template<typename T>
inline T& Firstt(typename std::queue<T>& q)
{
	return q.front();
}

template<typename T>
inline const typename T::value_type& Firstt(T& q)
{
	return q.top();
}



//template<typename T>
//inline T& Firstt(typename priority_queue<T>& q)
//{
//	return q.top();
//}
//;
