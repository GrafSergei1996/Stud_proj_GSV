#pragma once
template<typename T, class C>
void Prin(C c, T t)
{
	C c1(c);
	if ((typeid(C)) == (typeid(queue)))
	{
		T t1 = t;
		while (!c.empty())
		{
			std::cout << t1;
			c.pop_heap();
			t1 = c.top();
		}
		while (!c1.empty())
		{
			c.push(c1.top());
			c1.pop_heap();
		}
	}
	else if ((typeid(C)) == (typeid(priority_queue)))
	{
		T t1 = t;
		while (!c.empty())
		{
			std::cout << t1;
			c.pop();
			t1 = c.front();
		}
		while (!c1.empty())
		{
			c.push(c1.front());
			c1.pop();
		}
	}
	else (typeid(C)) == (typeid(stack))
	{
		T t1 = t;
		while (!c.empty())
		{
			std::cout << t1;
			c.pop();
			t1 = c.top();
		}
		while (!c1.empty())
		{
			c.push(c1.top());
			c1.pop();
		}
	}
}