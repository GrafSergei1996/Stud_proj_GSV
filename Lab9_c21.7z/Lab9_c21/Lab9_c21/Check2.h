#pragma once
#pragma warning(disable: 4786)
#include <iostream>
#include <iostream>
#include <vector>
#include<list>
#include<deque>
#include "Check.h"
template<typename T>
inline void PrintVectorValves(T& v)
{
	setlocale(LC_ALL, "Rus");
	std::cout << "������������ ������:" << v.max_size() << '\n' << "���������� ���������:" << v.size() << '\n' << "������ ���������:" << '\n';
	for (size_t i = 0; i < v.size(); i++)
	{
		std::cout << v[i] << '\n';
	}
}

template<typename T>
void DeleteDuble(T& v)
{
	typename T::iterator it1 = v.begin();
	typename T::iterator it2 = v.begin();
	//vector<char>::iterator it3 = vch.begin();
	++it2;
	while (it2 != v.end())
	{
		if (*it2 == *it1)
		{
			v.erase(it2);
			it2 = it1;
			++it2;
			//it3 = it2;
			//++it3;
		}
		else
		{
			++it2;
			++it1;
			//++it3;
		}
	}
}

template<typename T>
void DeleteSequences(T& v)
{
	typename T::iterator it1 = v.begin();
	typename T::iterator it2 = v.begin();
	typename T::iterator it3 = v.begin();
	//vector<char>::iterator it3 = vch.begin();
	++it2;
	while (it2 != v.end())
	{
		if (*it2 == *it1)
		{
			it3 = it2;
			while ((*it2 == *it1) && (it3 != v.end()))
			{
				v.erase(it2);
				it2 = it1;
				++it2;
				it3 = it2;
				++it3;
			}
			it2 = it1;
			++it2;
			if (*it2 == *it1)
			{
				v.erase(it2);
				v.erase(it1);
			}
			else
			{
				v.erase(it1);
			}
			it1 = v.begin();
			it2 = it1;
			++it2;
		}
		else
		{
			++it2;
			++it1;
			//++it3;
		}
	}
}

template<typename T>
inline void PrintValves(const T& v)

{
	typename T::const_iterator v1 = v.begin();
	typename T::const_iterator v2 = v.end();
	while (v1 != v2)
	{
		std::cout << *v1 << '\n';
		++v1;
		//++v2;
	}
}
