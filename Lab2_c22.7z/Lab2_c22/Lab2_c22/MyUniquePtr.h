#pragma once
template <typename T> class MyUniquePtr
{
	T* m_ptr;
public:
	MyUniquePtr() = default;
	MyUniquePtr& operator = (MyUniquePtr&&);
	MyUniquePtr(MyUniquePtr&&);
	T& operator* ();
	const T& operator* () const;
	T* operator ->();
	~MyUniquePtr();
	//MyUniquePtr<T>& operator = (const T*)
	MyUniquePtr<T>& operator = (const MyUniquePtr&) = delete;
	MyUniquePtr(T*);
	MyUniquePtr(const MyUniquePtr&) = delete;
};


template<typename T>
inline MyUniquePtr<T>& MyUniquePtr<T>::operator=(MyUniquePtr&& p)
{
		delete m_ptr;
		m_ptr = p.m_ptr;
		p.m_ptr = nullptr;
		return *this;
}

template<typename T>
inline MyUniquePtr<T>::MyUniquePtr(MyUniquePtr&& p)
{
	m_ptr = p.m_ptr;
	p.m_ptr = nullptr;
}

template<typename T>
inline T& MyUniquePtr<T>::operator*()
{
	return *m_ptr;
}

template<typename T>
inline const T& MyUniquePtr<T>::operator*() const
{
	return *m_ptr;
}

template<typename T>
inline T* MyUniquePtr<T>::operator->()
{
	return m_ptr;
}

template<typename T>
inline MyUniquePtr<T>::~MyUniquePtr()
{
	delete  m_ptr;
}

template<typename T>
inline MyUniquePtr<T>::MyUniquePtr(T* m):m_ptr(m)
{
	m = nullptr;
}

//template<typename T>
//inline MyUniquePtr<T>::MyUniquePtr(const T* p)
//{
//	m_ptr = p;
//	//p = nullptr;
//}
