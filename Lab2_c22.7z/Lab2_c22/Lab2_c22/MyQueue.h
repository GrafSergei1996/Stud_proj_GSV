#pragma once
#include<iostream>
#include<vector>
#include<iterator>
template <typename T> class MyQueue;
template <typename T> class MyQueueIterator
{
	friend class MyQueue<T>;
	MyQueue<T>* m_qp;
	size_t m_num;
	MyQueueIterator(MyQueue<T>* mq,size_t num):m_qp(mq),m_num(num)
	{ };
	//MyQueueIterator<T> operator= (const MyQueue<T>& t) { m_qp = t.m_ar; m_pcap = t.m_cap; return *this; };
public:
	MyQueueIterator() = default;
	~MyQueueIterator() =default;
	MyQueueIterator(const MyQueueIterator<T>&) = default;
	//MyQueueIterator(MyQueueIterator<T>&&) = default;
	MyQueueIterator<T> operator= (const MyQueueIterator<T>& it) /*= default */
{
		m_qp = it.m_qp;
		m_num = it.m_num;
};
	//MyQueueIterator<T> operator= (MyQueueIterator<T>&& it) 
	//{ m_qp = it.m_qp; m_num = it.m_num; it.m_qp = nullptr; };
	T& operator* ();
	const T& operator* () const;
	T* operator ->();
	MyQueueIterator<T> operator++();
};

template <typename T> class MyQueue
{
	friend class MyQueueIterator<T>;
	T* m_ar;
	size_t m_cap;
	size_t m_count;
	size_t m_first;
	size_t m_last;
protected:
	void resize(size_t);
public:
	MyQueueIterator<T> begin();
	MyQueueIterator<T> end();
	MyQueue() = default;
	MyQueue(const std::initializer_list<T>&);
	MyQueue(const MyQueue&);
	MyQueue(size_t n,const T&);
	MyQueue(MyQueue&&);
	MyQueue<T> operator = (const MyQueue&);
	MyQueue<T> operator = (MyQueue&&);
	MyQueue<T> operator = (const std::initializer_list<T>&);
	void push(const T&);
	void push(T&&);
	T pop();
	~MyQueue();

};


template<typename T>
inline void MyQueue<T>::resize(size_t n)
{
	T* ar = new T[n];
	m_cap = n;

	for (size_t i = 0; i < m_count; i++)
	{
		ar[i] = std::move(m_ar[(m_first + i) % m_cap]);
	}
	delete[] m_ar;
	m_ar = ar;
	m_first = 0;
	m_last = m_count - 1;
}

template<typename T>
inline MyQueueIterator<T> MyQueue<T>::begin()
{
	
	return MyQueueIterator<T>(this, m_first);
}

template<typename T>
inline MyQueueIterator<T> MyQueue<T>::end()
{
	return MyQueueIterator<T>(this, (m_last+1)%m_cap);
}

template<typename T>
inline MyQueue<T>::MyQueue(const std::initializer_list<T>& init)
{
	m_count = init.size();
	m_cap = m_count + 2;
	m_ar = new T[m_cap];
	int n = 0;
	for (auto& el : init)
	{
		m_ar[n] = el;
		n++;
	}
	
	m_first = 0;
	m_last = n - 1;
}

template<typename T>
inline MyQueue<T>::MyQueue(const MyQueue& mq)
{
	m_cap = mq.m_count+2;
	m_count = mq.m_count;
	m_first = 0;
	m_last = mq.m_count-1;
	m_ar = new T[m_cap];
	for (size_t n = 0; n < m_count; n++)
	{
		m_ar[n] = mq.m_ar[(mq.m_first + n) % mq.m_cap];
	}
}

template<typename T>
inline MyQueue<T>::MyQueue(size_t n, const T& t)
{
	m_cap = n + 2;
	m_count = n;
	m_first = 0;
	m_last = n - 1;
	for (size_t i = 0; i < m_count; i++)
	{
		m_ar[i] = t;
	}
}

template<typename T>
inline MyQueue<T>::MyQueue(MyQueue&& mq)
{

	m_cap = mq.m_cap;
	m_count = mq.m_count;
	m_first = mq.m_first;
	m_last = mq.m_last;
	m_ar = mq.m_ar;
	mq.m_ar = nullptr;

}

template<typename T>
inline MyQueue<T> MyQueue<T>::operator=(const MyQueue& mq)
{
	if (m_cap < mq.m_count)
	{
		delete[] m_ar;
		m_ar = new T[mq.m_count];
		m_cap = mq.m_count;
	}
	m_first = 0;
	m_count = mq.m_count;
	for (size_t i = 0; i < m_count; i++)
	{
		m_ar[i] = mq.m_ar[(mq.m_first + i) % mq.m_cap];
	}
	m_last = m_count-1;
	return *this;
}

template<typename T>
inline MyQueue<T> MyQueue<T>::operator=(MyQueue&& mq)
{
	if (this != &mq)
	{
	m_cap = mq.m_cap;
	m_count = mq.m_count;
	m_first = mq.m_first;
	m_last = mq.m_last;
	delete[] m_ar;

		m_ar = mq.m_ar;
		mq.m_ar = nullptr;
	}
	return *this;
}

template<typename T>
inline MyQueue<T> MyQueue<T>::operator=(const std::initializer_list<T>& init)
{
	if (m_cap < init.size())
	{
		delete[] m_ar;
		m_ar = new T[init.size()];
		m_cap = init.size();
	}
	m_first = 0;
	m_count = init.size();
	for (size_t i = 0; i < m_count; i++)
	{
		m_ar[i] = init[i];
	}
	m_last = m_count-1;
	return *this;
}

template<typename T>
inline void MyQueue<T>::push(const T& t)
{
	if (m_cap == m_count)
	{
		resize(m_cap + 2);
	}
	m_count++;
	m_last = (m_last+1)%m_cap;
	m_ar[m_last] = t;
}

template<typename T>
inline void MyQueue<T>::push(T&& t)
{
	if (m_cap == m_count+1)
	{
		resize(m_cap + 2);
	}
	m_count++;
	m_last = (m_last + 1) % m_cap;
	m_ar[m_last] = std::move(t);
}

template<typename T>
inline T MyQueue<T>::pop()
{
	m_count--;
	m_first = (m_first + 1) % m_cap;
	return std::move(m_ar[m_first-1]);
}

template<typename T>
inline MyQueue<T>::~MyQueue()
{
	delete [] m_ar;
}

template<typename T>
inline T& MyQueueIterator<T>::operator*()
{
	return (m_qp->m_ar)[m_num];
}

template<typename T>
inline const T& MyQueueIterator<T>::operator*() const
{
	return (m_qp->m_ar)[m_num];
}

template<typename T>
inline T* MyQueueIterator<T>::operator->()
{
	return &(m_qp->m_ar)[m_num];
}

template<typename T>
inline MyQueueIterator<T> MyQueueIterator<T>::operator++()
{
	m_num = (m_num + 1) % m_qp->m_cap;
	return *this;
}
//