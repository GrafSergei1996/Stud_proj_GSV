#include"MyUniqueVector.h"
#include"MyUniquePtr.h"
#include"myString.h"
#include"MyQueue.h"
int main()
{
	{
		MyUniqueVector<int> muv(-5, 5, { -10,2,2,4,4,1 });
		muv.push({ 1,2,10 });
		muv.pop({ 1,3 });
	}
	{
		MyUniquePtr<MyString> p1( new MyString("A") );
		std::cout << p1->GetString1();
		MyString  s2 = *p1;
		p1 = new MyString("B");
		MyUniquePtr<MyString> p2(new MyString("C"));
		p2 = (std::move_if_noexcept(p1));
		//std::vector< MyUniquePtr< MyString >> v ( /*{std::move(p1),}*/);
	}
	{
		MyQueue<MyString> mq {MyString("A"),MyString("B"), MyString("C"), MyString("D") };
		MyQueue<MyString> mq1 = mq;
		std::vector<MyString> v;
		//std::copy(mq.begin(), mq.end(), back_inserter(v));
		MyQueueIterator<MyString> it = mq.begin();
		++it;
		MyString s = *it;
		mq.push("F");
		mq.push("G");
		mq.push("E");
		s = mq.pop();
	}

}