#pragma once
#include<iostream>
#include<vector>
#include<iterator>
template <typename T> class MyUniqueVector
{
	std::vector<T> m_v;
	T m_low;
	T m_high;
public:
	MyUniqueVector() = default;
	~MyUniqueVector() = default;
	//MyUniqueVector(const T&,const T&,const size_t);
	MyUniqueVector(const T&, const T&, std::initializer_list<T>);
	void push(std::initializer_list<T>);
	void pop(std::initializer_list<T>);
	/*template <typename T1> */void sort1(size_t);
};

//template<typename T>
//inline MyUniqueVector<T>::MyUniqueVector(const T& l, const T& h, const size_t n)
//{ 
//	m_v = std::vector(n);
//	m_low = l;
//	m_high = h;
//}

template<typename T>
inline MyUniqueVector<T>::MyUniqueVector(const T& l, const T& h, std::initializer_list<T> init) :m_low(l), m_high(h)/*,m_v(init)*/
{
	typename std::initializer_list<T>::iterator it1 = init.begin();
	//if (((*it1) <= m_low) || ((*it1) >= m_high))
	//{
	//	m_v.push_back(*it1);
	//	++it1;
	//}
	//typename std::initializer_list<T>::iterator iti = init.begin();
	while (it1 != init.end())
	{
		if ((((*it1) >= m_low) && ((*it1) <= m_high)) && (find(m_v.begin(),m_v.end(),(*it1)) == m_v.end()))
		{
			m_v.push_back(*it1);
		}
		++it1;
	}
	//it1 = m_v.begin();
	//typename std::vector<T>::iterator it2 = m_v.begin();
	//++it2;
	//while (it1 != m_v.end())
	//{
	//	while(it2 != m_v.end())
	//	{
	//		if ((*it1) == (*it2))
	//		{
	//			m_v.erase(it2);
	//			it2 = it1;
	//			++it2;
	//		}
	//		else ++it2;
	//		if (it2 == m_v.end())
	//		{
	//			it2 = it1;
	//			break;
	//		}
	//	}
	//	if (it1 == m_v.end())
	//	{
	//		break;
	//	}
	//	else
	//	{
	//		++it1;
	//		it2 = it1;
	//		if (it2 == m_v.end())
	//		{
	//			break;
	//		}
	//		else
	//		++it2;
	//	}
	//}
}

template<typename T>
inline void MyUniqueVector<T>::push(std::initializer_list<T> init)
{
	typename std::initializer_list<T>::iterator iti = init.begin();

	while (iti != init.end())
	{
		typename std::vector<T>::iterator itv = find(m_v.begin(), m_v.end(), (*iti));
		if ((itv == m_v.end()))
		{
			m_v.insert(m_v.end(), *iti);
		}
		++iti;
		//while (itv != m_v.end())
		//{
		//	itv = find(init.begin(), init.end(), (*itv);)
		//	if (((*itv) != init.end()) && ((*iti) != (*itv)) && (m_v.size() != 0) )
		//	{
		//		++itv;
		//	}
		//	else 
		//	{
		//		break;
		//	}
		//}
		//if ((itv == m_v.end()) && ((*iti) >= m_low) && ((*iti) <= m_high) || (m_v.size() == 0) )
		//{
		//	
		//}

	}
}

template<typename T>
inline void MyUniqueVector<T>::pop(std::initializer_list<T> init)
{
	if (m_v.size() == 0)
	{
		return;
	}
	typename std::initializer_list<T>::iterator iti = init.begin();
	while (iti != init.end())
	{
		typename std::vector<T>::iterator itv = find(m_v.begin(),m_v.end(),(*iti));
		//typename std::initializer_list<T>::iterator iti = init.begin();
		if (itv != m_v.end())
		{
			m_v.erase(itv);
		}
		else
		{
			++iti;
		}
		//while (iti != init.end())
		//{
		//	if ((*itv) == (*iti))
		//	{
		//		m_v.erase(itv);
		//		iti = init.begin();
		//		itv = m_v.begin();
		//	}
		//	if (iti == init.end())
		//	{
		//		break;
		//	}
		//	++iti;
		//}
		//if (itv == m_v.end())
		//{
		//	break;
		//}
		//++itv;
	}
}

template<typename T>
inline void MyUniqueVector<T>::sort1(size_t pred)
{
	auto& pred1 = [](const T& x, const T& y) {return (x < y); };
	auto& pred2 = [](const T& x, const T& y) {return (x > y); };
		if (pred == 0)
		{
			sort(m_v.begin(), m_v.end(), pred2);
		}
		else
		{
			sort(m_v.begin(), m_v.end(), pred1);
		}
	
}

//template<typename T>
////template<typename T1>
//inline void MyUniqueVector<T>::sort1(size_t pred)
//{
//
//	sort(m_v.begin(), m_v.end(), pred);
//}
