#include<iostream>
#include<tchar.h>
#include"List.h"
#include"Rect.h"
#include"Circle.h"
int main()
{
	List l;
	l.AddToHead(Circle(static_cast<Color>(1),1,1,1));
	l.AddToHead(Rect(static_cast<Color>(0), 1, 2, 4, 8));
	l.AddToHead(Circle(static_cast<Color>(1), 1, 1, 1));
	l.AddToTail(Rect(static_cast<Color>(0), 1, 2, 4, 8));
	//l.DeleteFirstElement(Circle(static_cast<Color>(1), 1, 1, 1));
	//l.DeleteAllElements(Rect(static_cast<Color>(0), 1, 2, 4, 8));
	{
		List l1,l2;
		l1.AddToHead(Circle(static_cast<Color>(1), 1, 1, 1));
		l1.AddToHead(Rect(static_cast<Color>(0), 1, 2, 4, 8));
		l1.AddToHead(Circle(static_cast<Color>(1), 1, 1, 1));
		l1 = l;
		l1.SortList();
	}
	return 0;
}