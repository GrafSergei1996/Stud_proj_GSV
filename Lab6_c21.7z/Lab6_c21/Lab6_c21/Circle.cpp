#include"List.h"
#include "Circle.h"
#include<fstream>
//std::ostream& Circle::operator<<(std::ostream& out)
//{
//	out << cx << '\n' << cy << '\n' << rad << '\n';
//	return out;
//}

//std::istream& Circle::operator>>(std::istream& in)
//{
//		in >> cp.GetPointX() >> '\n' << cp.GetPointY() >> '\n' << rad << '\n';
//		return in;
//}
Circle::Circle():Shape()
{

}

Circle::Circle(Color c, int x, int y, int r) : Shape(c), cx(x), cy(y), rad(r)
{

}

Circle::Circle(const Shape& r):Shape(r)
{
	if (typeid(r) == typeid(Circle))
	{
		const Circle& r1 = static_cast<const Circle&>(r);
		cx = r1.cx;
		cy = r1.cy;
		rad = r1.rad;
	}

}

bool Circle::operator==(const Shape& c) const
{
	if (typeid(c) == typeid(Circle))
	{
		const Circle* cc = static_cast<const Circle*>(&c);
		return ((cx == cc->cx) && (cy == cc->cy) && (rad == cc->rad) && (Shape::operator==(c)));
	}
	else
		return false;
	
}

bool Circle::operator>(const Shape& c) const
{
	if (typeid(c) == typeid(Circle))
	{
		const Circle* cc = static_cast<const Circle*>(&c);
		return (rad > cc->rad);
	}
	else return false;
}

bool Circle::operator<(const Shape& c) const
{
	if (typeid(c) == typeid(Circle))
	{
		const Circle* cc = static_cast<const Circle*>(&c);
		return (rad < cc->rad);
	}
	else return false;
}

double Circle::Square()
{
	return 3.14159*rad*rad;
}

std::ostream& Circle::operator<<(std::ostream& out)
{
	setlocale(LC_ALL, "Rus");
	//if (typeid(c) == typeid(Circle))
	{
		//Circle* sh = static_cast<Circle*>(&c);
		out << "������ �����: " << rad << ' ' << ";���������� X: " << cx << ' ' << ";���������� Y: " << cy << ' ' << "����: ";
		this->Shape::operator << (out);
		out << '\n';
	}
	return out;
}

std::ofstream& Circle::operator<<(std::ofstream& fout)
{
	setlocale(LC_ALL, "Rus");
	fout << "������ �����: " << rad << ' ' << ";���������� X: " << cx << ' ' << ";���������� Y: " << cy << ' ' << "����: ";
	this->Shape::operator << (fout);
	fout << '\n';
	return fout;
}

std::ifstream& Circle::operator>>(std::ifstream& fin)
{
	//if (typeid(circ) == typeid(Circle))
	{
		//Circle* cc = static_cast<Circle*>(&circ);
		int a = -1, x, y, r, c=0, col = 0;
		char ch[50] = { 1 };
		while (ch[0] != EOF) //fin.ignore(1000,':')
		{
			c++;
			if (c == 11)
			{
				this->Shape::operator>>(fin);
				cx = x;
				cy = y;
				rad = r;
				c = 0;
			}
			if ((c % 3) != 0)
			{
				fin >> ch;
				a = ch[0];
			}
			if (a == 0)
			{
				break;
			}
			if (c == 3)
			{
				fin >> r;
			}
			if (c == 6)
			{
				fin >> x;
			}
			if (c == 9)
			{
				fin >> y;
			}
		}
	}
	return fin;
}

