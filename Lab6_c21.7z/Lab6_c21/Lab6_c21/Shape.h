#pragma once
#include<iostream>

enum Color {red,green,blue};
class Shape 
{

	Color col;
	friend class List;
protected:
	Shape();
	explicit Shape(const Shape&);
	explicit Shape(const Color);
	Shape& operator = (const Shape&);
	bool operator ==(const Shape&) const;
	virtual std::ostream& operator << (std::ostream&) const;
	virtual std::ofstream& operator << (std::ofstream&) const;
	virtual std::ifstream& operator >> (std::ifstream&);
	virtual double Square() { return 0; };
};