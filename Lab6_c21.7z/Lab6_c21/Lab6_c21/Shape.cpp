#include "Shape.h"
#include<fstream>
Shape::Shape():col(red)
{

}
Shape::Shape(const Shape& s):col(s.col)
{

}
Shape::Shape(const Color c) :col(c)
{

}

Shape& Shape::operator=(const Shape& c)
{
	col = c.col;
	return *this;
}

bool Shape::operator==(const Shape& sh) const
{
	return (col == sh.col);
}

std::ostream& Shape::operator<<(std::ostream& out) const
{
	out << col << '\n';
	return out;
}

std::ofstream& Shape::operator<<(std::ofstream& out) const
{
	out << col << '\n';
	return out;
}

std::ifstream& Shape::operator>>(std::ifstream& in)
{
	int a = static_cast<int>(col);
	in >> a;
	col = static_cast<Color>(a);
	return in;
}
