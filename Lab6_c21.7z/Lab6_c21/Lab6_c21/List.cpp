#include "List.h"
#include "Circle.h"
#include<iostream>
#include<fstream>
List::Node::Node()
{
	c = nullptr;
	pPrev = nullptr;
	pNext = nullptr;
}
List::Node::~Node()
{
	delete c;
	if (pPrev)
	{
		pPrev->pNext = this->pNext;
	}
	if (pNext)
	{
		pNext->pPrev = this->pPrev;
	}
}

bool List::Node::operator==(const Node& rc) const
{
	Shape& sh = static_cast<Shape&>(*c);
	const Shape* rcsh = static_cast<const Shape*>(rc.c);
	return (sh.operator == (*rcsh));
}

bool List::Node::operator>(const Node& rc) const 
{
	return (c>rc.c);
}

bool List::Node::operator<(const Node& rc)const
{
	return (c < rc.c);
}

std::ostream& List::Node::operator<<(std::ostream& out)
{
	out << c;
	return out;
}

List::Node::Node(const Shape& pP, Node* p)
{
	if (typeid(pP) == typeid(Circle))
	{
		c = new  Circle (pP);
	}
	if (typeid(pP) == typeid(Rect))
	{
		c = new  Rect(pP);
	}
	if (typeid(pP) == typeid(Shape))
	{
		c = new  Shape(pP);
	}
	pPrev = p;
	pNext = p->pNext;
	p->pNext = this;
	pNext->pPrev = this;
}

List::List()
{
	Head.pNext = &Tail;
	Tail.pPrev = &Head;
	m_size = 0;
}

List::~List()
{
	for (size_t i = 0; i < m_size; i++)
	{
		delete Head.pNext;
		//if (Head.pNext != nullptr)
		//{
		//	if (Head.pNext->pNext == nullptr)
		//	{
		//		return;
		//	}
		//	Node* p = Head.pNext->pNext;
		//	delete Head.pNext;
		//	Head.pNext = p;
		//}
	}
}

List::List(const List& l)// �� ��������� ��������� ����� ���� Head � Tail ��������� ���� �� ����� � ����� ����������� �� l � ��������� ��� ��� �������� �� ��� ����
{
	Head.pNext = &Tail;
	Tail.pPrev = &Head;
	m_size = l.m_size;
	Node* pP = &Head;
	Node* plist = l.Head.pNext;
	for (size_t i = 0;i < m_size; i++)
	{
		pP= new Node(*plist->c,pP);
		
		plist = plist->pNext;
		
	}
}

List::List(List&& l):m_size(l.m_size)
{
	if (l.m_size != 0/*l.Head.pNext->pNext != nullptr*/)
	{
		Head.pNext = l.Head.pNext;
		Head.pNext->pPrev = &Head;
	/*}
	if (l.Tail.pPrev->pPrev != nullptr)
	{*/
		Tail.pPrev = l.Tail.pPrev;
		l.Tail.pPrev->pNext = &Tail;
		l.Head.pNext = &l.Tail;
		l.Tail.pPrev = &l.Head;
	}
	else
	{
		Head.pNext = &Tail;
		Tail.pPrev = &Head;
	}

}

void List::AddToHead(const Shape& c)
{
	new Node (c,&Head);
	m_size++;
}

void List::AddToTail(const Shape& c)
{
	new Node(c, Tail.pPrev);
	m_size++;
}

bool List::DeleteFirstElement(const Shape& c)
{
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		if (*(p->c) == c)
		{
			delete p;
			m_size--;
			return true;
		}
		p = p->pNext;
	}
	return false;
}

//size_t List::DeleteAllCircle(const Circle& c)
//{
//	int n = 0;
//	Node* p = &Head;
//	for (size_t i = 0; i < m_size-1; i++)
//	{
//		p = p->pNext;
//		if ((p->c) == c)
//		{
//			Node* p1 = p;
//			p = p->pNext;
//			delete p1;
//			n++;
//		}
//	}
//	m_size = m_size-n;
//	return n;
//}

size_t List::DeleteAllElements(const Shape& c)
{
	int n = 0;
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		Node* p1 = p->pNext;
		if (*(p->c) == c)
		{
			delete p;
			n++;
		}
		p = p1;
	}
	m_size = m_size - n;
	return n;
}


//size_t List::DeleteAllCircle(const Circle& c)
//{
//	int n = 0;
//	Node* p = Head.pNext;
//	for (size_t i = 0; i < m_size ; i++)
//	{
//		Node* n = p->pNext;
//		if ((p->c) == c)
//		{
//			delete p;
//			n++;
//		}
//		p = n;
//	}
//	m_size = m_size - n;
//	return n;
//}

List& List::operator=(const List& l)
{
	if (m_size > l.m_size)
	{
		for (size_t i = l.m_size; i < m_size; i++)
		{
			delete Head.pNext;
		}
	}
		Node* p = Head.pNext;
		Node* pl = l.Head.pNext;
		for (size_t i = 0; i < m_size; i++)
		{
			if (typeid(*(p->c)) == typeid(*(pl->c)))
			{
				*(p->c) = *(pl->c);
			}
			else
			{
				Node* p1 = p->pPrev;
				delete p;
				p1 = new Node(*pl->c, p1);
			}
			p = p->pNext;
			pl = pl->pNext;
		}
		p = &Head;
		if (m_size == l.m_size)
		{
			return *this;
		}
		else
		{
			for (size_t i = m_size; i < l.m_size; i++)
			{
				p = new Node(*pl->c, p);
				pl = pl->pNext;
			}
		}
	return *this;
}

List& List::operator=(List&& l)
{
	DeleteAll();
	m_size = l.m_size;
	if (l.m_size != 0/*l.Head.pNext->pNext != nullptr*/)
	{
		Head.pNext = l.Head.pNext;
		l.Head.pNext->pPrev = &Head;
		/*}
		if (l.Tail.pPrev->pPrev != nullptr)
		{*/
		Tail.pPrev = l.Tail.pPrev;
		l.Tail.pPrev->pNext = &Tail;
		l.Head.pNext = &l.Tail;
		l.Tail.pPrev = &l.Head;
	}
	return *this;
}

void List::DeleteAll()
{
	for (size_t i = 0; i < m_size; i++)
	{
		delete Head.pNext;
	}
	m_size = 0;
}

void List::SortList()
{
	if (m_size != 0)
	{
		for (size_t i = 0; i < m_size - 1; i++)
		{
			Node* pmax = Head.pNext;
			bool b = false;
			for (size_t j = 0; j < m_size - i - 1; j++)
			{
				if (pmax->c->Square() > pmax->pNext->c->Square())
				{
					pmax->pNext->pPrev = pmax->pPrev;
					pmax->pNext = pmax->pNext->pNext;
					pmax->pPrev = pmax->pNext->pPrev;
					pmax->pPrev->pNext = pmax;
					pmax->pPrev->pPrev->pNext = pmax->pPrev;
					pmax->pNext->pPrev = pmax;
					b = true;
				}
				if (!b)
				{
					pmax = pmax->pNext;
				}
			}

		}
	}
}

std::ostream& List::operator<<(std::ostream& out)
{
	setlocale(LC_ALL, "Rus");
	out << "����� ���������:" << this->m_size << '\n';
	out << "������ ���������:" << '\n';
	Node* p = Head.pNext;
	for (size_t i = 0; i < this->m_size; i++)
	{
		if (typeid(*(p->c)) == typeid(Circle))
		{
			Circle* pc = static_cast<Circle*>(p->c);
			pc->operator<<(out);
			//out << '\n';
		}
		if (typeid(*(p->c)) == typeid(Rect))
		{
			Rect* pc = static_cast<Rect*>(p->c);
			pc->operator<<(out);
			//out << '\n';
		}
		if (typeid(*(p->c)) == typeid(Shape))
		{
			p->c->operator<<(out);
			//out << '\n';
		}
		p = p->pNext;
	}
	return out;
}

std::ifstream& List::operator>>(std::ifstream& fin)
{
	DeleteAll();
	int a=-1,x,y,r,color,right,left,top,bot,c=0;
	char ch[50] = {1};
	while (ch[0] != '\0') //fin.ignore(1000,':')
	{
		fin >> ch;
		if (!strcmp(ch, "����:"))
		{
			while (ch[0] != '\n')
			{
				c++;
				if (c == 11)
				{
					fin >> color;
					AddToHead(Circle(static_cast<Color>(color), x, y, r));
					c = 0;
					a = 0;
				}
				if (((c % 3) != 0) && (c != 11))
				{
					fin >> ch;
					a = ch[0];
				}
				if (a == 0)
				{
					break;
				}
				if (c == 3)
				{
					fin >> r;
				}
				if (c == 6)
				{
					fin >> x;
				}
				if (c == 9)
				{
					fin >> y;
				}
			}
		}
		if (!strcmp(ch, "�������������:"))
		{
			while (ch != "\n") //fin.ignore(1000,':')
			{
				c++;
				if (c == 18)
				{
					fin >> color;
					AddToHead(Rect(static_cast<Color>(color), right, left, top, bot));
					c = 0;
					a = 0;
				}
				if (((c % 4) != 0) && (c != 18))
				{
					fin >> ch;
					a = ch[0];
				}
				if (a == 0)
				{
					break;
				}
				if (c == 4)
				{
					fin >> right;
				}
				if (c == 8)
				{
					fin >> left;
				}
				if (c == 12)
				{
					fin >> top;
				}
				if (c == 16)
				{
					fin >> bot;
				}
			}
		}
		if (!strcmp(ch, "�����:"))
		{
			fin >> color;
			AddToHead(Shape(static_cast<Color>(color)));
		}
	}
	return fin;
}

std::ofstream& List::operator<<(std::ofstream& fout)
{
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		if (typeid(*p->c) == typeid(Circle))
		{
			fout << "����: ";
			Circle* pc = static_cast<Circle*>(p->c);
			pc->operator << (fout);
		}
		if (typeid(*p->c) == typeid(Shape))
		{
			fout << "�����: ";
			p->c->operator << (fout);
		}
		if (typeid(*p->c) == typeid(Rect))
		{
			fout << "�������������: ";
			Rect* pc = static_cast<Rect*>(p->c);
			pc->operator << (fout);
		}
		p = p->pNext;
	}
	return fout;
}

std::ostream& operator<<(std::ostream& out, List& l)
{
	l.operator<<(out);
	return out;
}

std::ofstream& operator<<(std::ofstream& fout, List& l)
{
	l.operator<<(fout);
	return fout;
}

std::ifstream& operator>>(std::ifstream& fin, List& l)
{
	l.operator>>(fin);
	return fin;
}
