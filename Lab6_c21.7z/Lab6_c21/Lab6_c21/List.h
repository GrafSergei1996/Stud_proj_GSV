#pragma once
#include"Circle.h"
#include"Rect.h"
#include<iostream>
#include<fstream>
class List
{
	class Node
	{
		friend class List;
		Shape* c;
		Node* pPrev;
		Node* pNext;
		Node();
		~Node();
		Node(const Shape&, Node*);
		bool operator == (const Node&) const;
		bool operator > (const Node&) const;
		bool operator < (const Node&) const;
		std::ostream& operator << (std::ostream&);
	};
	Node Head;
	Node Tail;
	size_t m_size;
public:
	List();
	~List();
	List(const List&);
	List(List&&);
	void AddToHead(const Shape&);
	void AddToTail(const Shape&);
	bool DeleteFirstElement(const Shape&);
	size_t DeleteAllElements(const Shape&);
	List& operator = (const List&);
	List& operator = (List&&);
	void DeleteAll();
	void SortList();
	virtual std::ostream& operator << (std::ostream&);
	virtual std::ifstream& operator >> (std::ifstream&);
	friend std::ostream& operator << (std::ostream&, List&);
	virtual std::ofstream& operator << (std::ofstream&);
	friend std::ofstream& operator << (std::ofstream&, List&);
	friend std::ifstream& operator >> (std::ifstream&, List&);
};