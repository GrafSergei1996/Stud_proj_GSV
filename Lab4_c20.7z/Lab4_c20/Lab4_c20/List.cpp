#include "List.h"
#include "Circle.h"
#include<iostream>
#include<fstream>
List::Node::Node()
{
	pPrev = nullptr;
	pNext = nullptr;
}
List::Node::~Node()
{
	if (pPrev)
	{
		pPrev->pNext = this->pNext;
	}
	if (pNext)
	{
		pNext->pPrev = this->pPrev;
	}
}

bool List::Node::operator==(const Node& rc) const
{
	return (c == rc.c);
}

bool List::Node::operator>(const Node& rc) const 
{
	return (c>rc.c);
}

bool List::Node::operator<(const Node& rc)const
{
	return (c < rc.c);
}

std::ostream& List::Node::operator<<(std::ostream& out)
{
	out << c;
	return out;
}

List::Node::Node(const Circle& pP, Node* p)
{
	pPrev = p;
	pNext = p->pNext;
	p->pNext = this;
	pNext->pPrev = this;
	c = pP;
}

List::List()
{
	Head.pNext = &Tail;
	Tail.pPrev = &Head;
	m_size = 0;
}

List::~List()
{
	for (size_t i = 0; i < m_size; i++)
	{
		if (Head.pNext != nullptr)
		{
			if (Head.pNext->pNext == nullptr)
			{
				return;
			}
			Node* p = Head.pNext->pNext;
			delete Head.pNext;
			Head.pNext = p;
		}
	}
}

List::List(const List& l):Head(l.Head),Tail(l.Tail)
{
	m_size = l.m_size;
}

void List::AddToHead(const Circle& c)
{
	new Node(c, &Head);
	m_size++;
}

void List::AddToTail(const Circle& c)
{
	new Node(c, Tail.pPrev);
	m_size++;
}

bool List::DeleteFirstCircle(const Circle& c)
{
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		if ((p->c) == c)
		{
			delete p;
			m_size--;
			return true;
		}
		p = p->pNext;
	}
	return false;
}

size_t List::DeleteAllCircle(const Circle& c)
{
	int n = 0;
	for (size_t i = 0; i < m_size; i++)
	{
		Node* p = Head.pNext;
		if ((p->c) == c)
		{
			delete p;
			n++;
		}
		//p = Head.pNext;
	}
	m_size = m_size-n;
	return n;
}

void List::DeleteAll()
{
	for (size_t i = 0; i < m_size; i++)
	{
		delete Head.pNext;
	}
	m_size = 0;
}

void List::SortList()
{
	if (m_size != 0)
	{
		for (size_t i = 0; i < m_size - 1; i++)
		{
			Node* pmax = Head.pNext;
			bool b = false;
			for (size_t j = 0; j < m_size - i - 1; j++)
			{
				if (pmax->c.rad > pmax->pNext->c.rad)
				{
					pmax->pNext->pPrev = pmax->pPrev;
					pmax->pNext = pmax->pNext->pNext;
					pmax->pPrev = pmax->pNext->pPrev;
					pmax->pPrev->pNext = pmax;
					pmax->pPrev->pPrev->pNext = pmax->pPrev;
					pmax->pNext->pPrev = pmax;
					b = true;
				}
				if (!b)
				{
					pmax = pmax->pNext;
				}
			}

		}
	}
}

std::ostream& List::operator<<(std::ostream& out)
{
	setlocale(LC_ALL, "Rus");
	out << "����� ���������:" << m_size << '\n';
	out << "������ ���������:" << '\n';
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		p->operator<<(out);
		p = p->pNext;
	}
	return out;
}

std::ifstream& List::operator>>(std::ifstream& fin)
{
	DeleteAll();
	int a=-1,x,y,r,c=0;
	char ch[50] = {1};
	while (ch[0] != EOF)
	{
		c++;
		if ((c % 3) != 0)
		{
			fin >> ch;
			a = ch[0];
		}
		if (a == 0)
		{
			break;
		}
		if (c == 3)
		{
			fin >> r;
		}
		if (c == 6)
		{
			fin >> x;
		}
		if (c == 9)
		{
			fin >> y;
			AddToTail(Circle(x, y, r));
			c = 0;
		}
	}
	return fin;
}

std::ofstream& List::operator<<(std::ofstream& fout)
{
	Node* p = Head.pNext;
	for (size_t i = 0; i < m_size; i++)
	{
		fout << (p->c);
		p = p->pNext;
	}
	return fout;
}

std::ostream& operator<<(std::ostream& out, List& l)
{
	l.operator<<(out);
	return out;
}

std::ofstream& operator<<(std::ofstream& fout, List& l)
{
	l.operator<<(fout);
	return fout;
}

std::ifstream& operator>>(std::ifstream& fin, List& l)
{
	l.operator>>(fin);
	return fin;
}
