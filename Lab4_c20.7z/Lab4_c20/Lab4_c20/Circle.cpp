#include"List.h"
#include "Circle.h"
#include<fstream>
std::ostream& Circle::operator<<(std::ostream& out)
{
	out << cp.GetPointX() << '\n' << cp.GetPointY() << '\n' << rad << '\n';
	return out;
}

//std::istream& Circle::operator>>(std::istream& in)
//{
//		in >> cp.GetPointX() >> '\n' << cp.GetPointY() >> '\n' << rad << '\n';
//		return in;
//}

bool Circle::operator==(const Circle& c) const
{
	if ((cp.GetPointX() == c.cp.GetPointX()) && (cp.GetPointY() == c.cp.GetPointY()) && (rad == c.rad))
		return true; 
	else
	return false;
}

bool Circle::operator>(const Circle& c) const
{
	return (rad > c.rad);
}

bool Circle::operator<(const Circle& c) const
{
	return (rad < c.rad);
}

Circle::Circle(int x, int y, int nrad)
{
	cp.SetPoint(x, y);
	rad = nrad;
}
Circle::Circle(const Point& p, int nrad)
{
	cp = p;
	rad = nrad;
}
Circle::Circle(const Circle& c)
{
	int x, y;
	c.cp.GetPoint(x, y);
	cp.SetPoint(x, y);
	rad = c.rad;
}

Circle::Circle()
{
	rad = 0;
}

std::ostream& operator<<(std::ostream& out, Circle& c)
{
	out << "������ �����: " << c.rad << ' ' << ";���������� X: " << c.cp.GetPointX() << ' ' << ";���������� Y: " << c.cp.GetPointY() << ' ' << '\n';
	return out;
}

std::ofstream& operator<<(std::ofstream& fout, Circle& c)
{
	fout << "������ �����: " << c.rad << ' ' << ";���������� X: " << c.cp.GetPointX() << ' ' << ";���������� Y: " << c.cp.GetPointY() << ' ' << '\n';
	return fout;
}

std::ifstream& operator>>(std::ifstream& fin, Circle& c)
{
	int x, y;
	fin >> c.rad >> x >> y;
	return fin;
}

