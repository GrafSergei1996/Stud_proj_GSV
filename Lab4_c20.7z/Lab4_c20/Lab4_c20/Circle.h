#pragma once
#include"List.h"
#include"Point.h"
#include<iostream>
#include<fstream>
class Circle
{
	//friend class Node;
	friend class List;
	Point cp;
	int rad;
	std::ostream& operator << (std::ostream&);
	//std::istream& operator >> (std::istream&);
	bool operator == (const Circle&) const;
	bool operator > (const Circle&) const;
	bool operator < (const Circle&) const;
	friend std::ostream& operator << (std::ostream&, Circle&);
	friend std::ofstream& operator << (std::ofstream&, Circle&);
	friend std::ifstream& operator >> (std::ifstream&, Circle&);
public:
	Circle(int, int, int);
	Circle(const Point&, int);
	Circle();
	Circle(const Circle&);
};