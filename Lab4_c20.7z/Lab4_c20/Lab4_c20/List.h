#pragma once
#include"Circle.h"
#include<iostream>
#include"Point.h"
#include<fstream>
class List
{
	class Node
	{
		friend class List;
		Circle c;
		Node* pPrev;
		Node* pNext;
		Node();
		~Node();
		Node(const Circle&, Node*);
		bool operator == (const Node&) const;
		bool operator > (const Node&) const;
		bool operator < (const Node&) const;
		std::ostream& operator << (std::ostream&);
	};
	Node Head;
	Node Tail;
	size_t m_size;
public:
	List();
	~List();
	List(const List&);
	void AddToHead(const Circle&);
	void AddToTail(const Circle&);
	bool DeleteFirstCircle(const Circle&);
	size_t DeleteAllCircle(const Circle&);
	void DeleteAll();
	void SortList();
	std::ostream& operator << (std::ostream&);
	std::ifstream& operator >> (std::ifstream&);
	friend std::ostream& operator << (std::ostream&, List&);
	std::ofstream& operator << (std::ofstream&);
	friend std::ofstream& operator << (std::ofstream&, List&);
	friend std::ifstream& operator >> (std::ifstream&, List&);
};