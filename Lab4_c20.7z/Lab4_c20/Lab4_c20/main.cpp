#include <tchar.h>
#include<iostream>
#include"List.h"
#define	  stop __asm nop

int _tmain(int argc, _TCHAR* argv[])
{
	Circle c=Circle(1,1,5);
	List l;
	l.AddToHead(c);
	l.AddToHead(Circle(-1, 2, 4));
	l.AddToTail(Circle(1, 1, 3));
	l.AddToTail(Circle(14, 8, 6));
	l.SortList();
	std::cout << l;
	std::ofstream fout("List.txt");
	fout << l;
	fout.close();
	List l1;
	std::ifstream fin("List.txt");
	fin >> l1;
	fin.close();
	return 0;
}