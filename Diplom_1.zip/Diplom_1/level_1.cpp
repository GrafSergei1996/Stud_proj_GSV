#include "level_1.h"
void Level::binarization()
{
    for (int i = 0; i < 60; ++i) {
        for (int j = 0; j < 60; ++j) {
            arrayUserVer[i][j] = 0;
        }
    }
    enterImage.save(QStringLiteral("Images_bw/level") + QString::number(num) + QStringLiteral(".jpg"));
    enterImage.load(QStringLiteral("Images_bw/level") + QString::number(num) + QStringLiteral(".jpg"));
    resultImage = QImage(enterImage);
    //QImage image1 = QImage(100,100,QImage::Format_RGB32);
    resultImage = resultImage.scaled(240,240);
    //image.load(QStringLiteral("Images/test_picture1.jpg"));
    //метод бинаризации
    const int wid = resultImage.width();
    const int hei = resultImage.height();
    const int d = resultImage.height()/18;
    const int R = 128;
    const int t = 0.99;
    int s2 = d/2;
    int integral_image[wid][hei];
    for (int i = 0;i < resultImage.width();++i)
    {
        int j = 0;
        while (j != resultImage.height())
        {
            QColor getcolor = resultImage.pixelColor(i,j);
            int graycolorR,graycolorG,graycolorB,graycolor4;
            int* graycolorRptr = &graycolorR;
            int* graycolorGptr = &graycolorG;
            int* graycolorBptr = &graycolorB;
            int* graycolor4ptr = &graycolor4;
            getcolor.getRgb(graycolorRptr,graycolorGptr,graycolorBptr,graycolor4ptr);
            int graycolor = 0.2125*graycolorR + 0.7154*graycolorG + 0.0721*graycolorB;

            if ((i == 0) && (j == 0))
            {
                integral_image[i][j] = graycolor;
            }
            if (i == 0)
            {
                integral_image[i][j] = graycolor+integral_image[i][j-1];
            }
            else if (j == 0)
            {
                integral_image[i][j] = graycolor+integral_image[i-1][j];
            }
            else
            {
                integral_image[i][j] = graycolor + integral_image[i-1][j]+integral_image[i][j-1]-integral_image[i-1][j-1];
            }
            QColor setcolor = QColor(graycolor,graycolor,graycolor);
            resultImage.setPixelColor(i,j,setcolor);
            j++;
        }
    }
    //прогонка
    int x1,y1,x2,y2;
    for (int i = 0; i < resultImage.width(); i++) {
      for (int j = 0; j < resultImage.height(); j++) {
        int index = j * resultImage.width() + i;
        int graycolorR,graycolor;
        int* graycolorRptr = &graycolorR;
        QColor getcolor = resultImage.pixelColor(i,j);
        getcolor.getRgb(graycolorRptr,graycolorRptr,graycolorRptr);
        x1=i-s2;
        x2=i+s2;
        y1=j-s2;
        y2=j+s2;
        if (x1 < 0)
      x1 = 0;
        if (x2 >= resultImage.width())
      x2 = resultImage.width()-1;
        if (y1 < 0)
      y1 = 0;
        if (y2 >= resultImage.width())
      y2 = resultImage.width()-1;

        int count = (x2-x1)*(y2-y1);

        int sum = integral_image[x2][y2] - integral_image[x2][y1] - integral_image[x1][y2] + integral_image[x1][y1];
        if ((graycolorR*count) < (sum*(1.0-0.07)))
        graycolor = 0;
        else
        graycolor = 255;
        QColor setcolor = QColor(graycolor,graycolor,graycolor);
        resultImage.setPixelColor(i,j,setcolor);
      }
    }
    //фильтрация
    QVector<int> vec;
    //int h,w;
    for (int h = 1; h < resultImage.height()-1; h++)
    {
        for(int w = 1; w < resultImage.width()-1; w++)
        {

            vec.append(QColor(resultImage.pixel(w-1,h-1)).green());
            vec.append(QColor(resultImage.pixel(w,h-1)).green());
            vec.append(QColor(resultImage.pixel(w+1,h-1)).green());
            vec.append(QColor(resultImage.pixel(w-1,h)).green());
            vec.append(QColor(resultImage.pixel(w,h)).green());
            vec.append(QColor(resultImage.pixel(w+1,h)).green());
            vec.append(QColor(resultImage.pixel(w-1,h+1)).green());
            vec.append(QColor(resultImage.pixel(w,h+1)).green());
            vec.append(QColor(resultImage.pixel(w+1,h+1)).green());
            qSort(vec.begin(),vec.end());
            resultImage.setPixel(w,h,QColor(vec.at(4),vec.at(4),vec.at(4)).rgb());
            vec.clear();
        }
    }
    //pix = QPixmap::fromImage(img);
    //
    resultImage.save(QStringLiteral("Images_bw/level") + QString::number(num) + QStringLiteral(".jpg"));
}

void Level::formArrays()
{
    testImage = QImage(resultImage);
    for (int i = 0; i < 60;i++)
    {
        int j = 0;
        while (j != 60)
        {
            bool kras =0;
            for (int m = 0; m < 4;m++)
            {
                int count = 0;
                int n = 0;
                while (n != 4)
                {
                    QColor col = testImage.pixelColor(i*4+m,j*4+n);
                    int gray = col.green();
                    count;
                    if (gray == 0)
                    {
                        count++;
                    }
                    if (count >= 8)
                    {
                        //arrayPict[i][j] = true;
                        kras = 1;
                    }
                    n++;
                }
            }
            if (kras)
            {
                for (int m = 0; m < 4;m++)
                {
                    int n = 0;
                    while (n != 4)
                    {
                        testImage.setPixelColor(i*4+m,j*4+n,QColor(0,0,0));
                        n++;
                    }
                }
            }
            j++;
        }
    }
    // формирование arrayPict
    for (int i = 0; i < 60;i++)
    {
        int j = 0;
        while (j != 60)
        {
            QColor col = testImage.pixelColor(i*4,j*4);
            int gray = col.green();
            if (gray == 0)
            {
                arrayPict[i][j] = true;
            }
            else {
               arrayPict[i][j] = false;
            }
            j++;
        }
    }
    //bool arrayPictInv[60][60];
    for (int i = 0; i < 60;i++)
    {
        int j = 0;
        while (j != 30)
        {
            arrayVert[i][j] = 0;
            arrayHor[j][i] = 0;
            //arrayPictInv[i][j] = arrayPict[j][i];
            j++;
        }
    }
    //формирование arrayVert и arrayHor
    for (int i = 0; i < 60;i++)
    {
        int numHor = 0;
        int numVert = 0;
        int ind = -1;
        int ind1 = -1;
        int j = 0;
        while (j != 60)
        {
            //arrayHor
            //arrayHor[j/2][i] = 0;
            if (arrayPict[j][i] == false)
            {
                ind = 1;
            }
            else
            {
                ind = 0;
            }
            if ((arrayPict[j][i] == false) &&(arrayPict[j+1][i] == true))
            {
                numHor++;
            }
            if (ind%2 == 0)
            {
                arrayHor[numHor][i]++;
            }
            //arrayVert
            //arrayVert[j/2][i] = 0;
            if (arrayPict[i][j] == false)
            {
                ind1 = 1;
            }
            else
            {
                ind1 = 0;
            }
            if ((arrayPict[i][j] == false) &&(arrayPict[i][j+1] == true))
            {
                numVert++;
            }
            if (ind1%2 == 0)
            {
                arrayVert[i][numVert]++;
            }
            j++;
        }
    }
    testImage.save(QStringLiteral("Images_bw/level") + QString::number(num) + QStringLiteral(".jpg"));
}

Level::Level(QWidget *parent) : QWidget(parent)
{

}

void Level::setImage(QImage * img)
{
    enterImage = *img;
    binarization();
    formArrays();
}

void Level::setNum(int i)
{
    num = i;
}

//void Level::setImage(QImage* img)
//{
//    enterImage = *img;
//    binarization();
//    formArrays();
//}

//void Level::setImage(QImage img)
//{
//    enterImage = img;
//    binarization();
//    formArrays();
//}

//Level::Level(QImage img)
//{
//    enterImage = img;

//}
