#ifndef LEVELS_1_H
#define LEVELS_1_H

#include <QWidget>
#include <QImage>
#include <QPainter>
#include <QScrollArea>
#include "level_1.h"
#include <QSize>
#include <QMouseEvent>
#include <QPoint>
#include <QFileDialog>
#include<QStringList>
#include <QFile>
#include <QTextStream>
#include <QChar>
#include "levelcombobox.h"
class levels_1 : public QWidget
{
    Q_OBJECT
    QVector<Level*> levels;
    bool arrayUserPict[60][60];
    int currLevel;
    bool GameOn;
    int maxHorizontalSmesh;
    int maxVerticalSmesh;
    int mashtab;
    int idtimer;
    //bool BoxIsInit;
public:
    explicit levels_1(QWidget *parent = nullptr);
    ~levels_1();

signals:
    void signalButtonText(QString);
    void signalNewLabel(QString);
    void signalDeleteItems();
    void signalEndGame(int);
public slots:
    void SetLevel(int);
    void slotGameOn();
    void slotDeleteLevel();
    //void slotBoxInit
//    void slotAddlevel();
    void slot1();
    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);

    // QWidget interface
protected:
    virtual void keyPressEvent(QKeyEvent *event);

    // QWidget interface
protected:
    virtual void mousePressEvent(QMouseEvent *event);

    // QWidget interface
protected:
    virtual void keyReleaseEvent(QKeyEvent *event);

    // QObject interface
protected:
    virtual void timerEvent(QTimerEvent *event);
};

#endif // LEVELS_1_H
