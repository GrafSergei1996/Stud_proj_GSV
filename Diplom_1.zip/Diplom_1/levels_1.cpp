#include "levels_1.h"

levels_1::levels_1(QWidget *parent) : QWidget(parent)
{
    currLevel = 1;
    idtimer = startTimer(100);
    //bool TEST = line1[0].unicode();
    for (int i = 0; i < 60; ++i) {
        for (int j = 0; j < 60; ++j) {
            arrayUserPict[i][j] = 0;
        }
    }
    mashtab = 20;
    GameOn = false;  
    QString line1;
    QFile file("levels.txt");
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text))
        return;
    int LevelCount = 0;
    QTextStream in(&file);
    int shetchik = 0;
    int RecordCurrLev =0;
    QVector<int> TESTVECTOR;
    while (!in.atEnd()) {
        line1 = in.readLine();
        if (shetchik == 0)
        {
            LevelCount = line1.toInt();
        }
        if (LevelCount != 0)
        {
            if ((shetchik-1)%61 == 0)
            {
                QImage* newImg = new QImage(QStringLiteral("Images_bw/level") + QString::number(RecordCurrLev) + QStringLiteral(".jpg"));
                Level* lev1 = new Level(this);
                levels.append(lev1);
                levels[RecordCurrLev]->num = RecordCurrLev;
                levels[RecordCurrLev]->setImage(newImg);
                RecordCurrLev++;
            }
            if (((shetchik-1)%61 >0) && ((shetchik-1)%61 <61) )
            {
                //if (shetchik == 60) {}
                int k = 0;
                while ( k != 60)
                {
                    //ushort znach = line1[k].unicode();
                    //bool l = static_cast<bool>(znach);
                    //levels[RecordCurrLev-1]->arrayUserVer[(shetchik-1)%61][10] = l;
                    TESTVECTOR.append(line1[k].unicode()-48);
                    k++;
                }
            }
            if (TESTVECTOR.size() == 3600)
            {
                for (int i = 0; i < 60; ++i) {
                    for (int j = 0; j < 60; ++j) {
                        levels[RecordCurrLev-1]->arrayUserVer[i][j] = TESTVECTOR[i*60+j];
                    }
                }
            }
           shetchik++;
        }
    }
    file.close();
    //Level* lev1 = new Level(this);
    //levels.append(lev1);
    //QImage* img1 = new QImage(QStringLiteral("Images_bw/level") + QString::number(1) + QStringLiteral(".jpg"));
    //levels[0]->num = 0;
    //levels[0]->setImage(img1);
    this->setFont(QFont("Times", mashtab/2));
    //repaint();
    //QSize sizeWidget = this->size();
    //this->resize(sizeWidget/2);
    this->repaint();
}

levels_1::~levels_1()
{
    QFile file("levels.txt");
    if (!file.open(QIODevice::WriteOnly | QIODevice::Text))
    return;
    QTextStream out(&file);

    out << levels.size() << "\n";
    for (int l = 0; l < levels.size(); ++l) {
        out << QStringLiteral("Images_bw/level") + QString::number(l) + QStringLiteral(".jpg") << "\n";
        for (int i = 0; i < 60; ++i) {
            for (int j = 0; j < 60; ++j) {
                out << arrayUserPict[i][j];
            }
            out << "\n";
        }
    }
    file.close();
    //out << "The magic number is: " << 49 << "\n";
}

void levels_1::SetLevel(int i)
{
    GameOn = false;
    currLevel = i+1;
    this->repaint();
}

void levels_1::slotGameOn()
{
    if (GameOn == true)
    {
        GameOn = false;
        emit signalButtonText(QStringLiteral("Прервать игру"));
    }
    else
    {
        if (levels.size() > 0)
        {
            GameOn = true;
            //проверка
            for (int i = 0;i<60;i++)
            {
                bool nextStroka1,nextStroka2,nextStroka3,nextStroka4;
                int j = 0;
                while (j != (60))
                {
                    arrayUserPict[i][j] = levels[currLevel-1]->arrayUserVer[i][j];
                    if (levels[currLevel-1]->arrayUserVer[0][j])
                    {
                        nextStroka1 = true;
                    }
                    if (levels[currLevel-1]->arrayUserVer[j][0])
                    {
                        nextStroka2 = true;
                    }
                    if (levels[currLevel-1]->arrayUserVer[59][j])
                    {
                        nextStroka3 = true;
                    }
                    if (levels[currLevel-1]->arrayUserVer[j][59])
                    {
                        nextStroka4 = true;
                    }
                    j++;
                }
                if (nextStroka1)
                {
                    arrayUserPict[0][i] = levels[currLevel-1]->arrayPict[0][i];
                }
                else {
                    arrayUserPict[1][i] = levels[currLevel-1]->arrayPict[1][i];
                }
                if (nextStroka2)
                {
                    arrayUserPict[i][0] = levels[currLevel-1]->arrayPict[i][0];
                }
                else {
                    arrayUserPict[i][1] = levels[currLevel-1]->arrayPict[i][1];
                }
                if (nextStroka3)
                {
                    arrayUserPict[59][i] = levels[currLevel-1]->arrayPict[59][i];
                }
                else {
                    arrayUserPict[58][i] = levels[currLevel-1]->arrayPict[58][i];
                }
                if (nextStroka4)
                {
                    arrayUserPict[i][59] = levels[currLevel-1]->arrayPict[i][59];
                }
                else {
                    arrayUserPict[i][58] = levels[currLevel-1]->arrayPict[i][58];
                }
            }
            emit signalButtonText(QStringLiteral("Продолжить игру"));
        }
    }
    this->repaint();
}

void levels_1::slotDeleteLevel()
{
    if (levels.size() > 0)
    {
        if (GameOn == true)
        {
            GameOn = false;
        }
        levels.remove(currLevel-1);
        emit signalDeleteItems();
        for (int i = 0; i < levels.size();i++)
        {
            levels[i]->testImage.save(QStringLiteral("Images_bw/level") + QString::number(levels[i]->num) + QStringLiteral(".jpg"));
            emit signalNewLabel(QString::number(i+1));
        }
        this->repaint();
    }
}

//void levels_1::slotAddlevel()
//{
//    QFileDialog dialog;
//    dialog.setNameFilter(tr("Images (*.png *.xpm *.jpg)"));
//    QString str = dialog.getOpenFileName();
//    QImage* img1 = new QImage(str);
//    Level* lev1 = new Level(this);
//    lev1->setImage(img1);
//    levels.append(lev1);
//}

void levels_1::slot1()
{
    QFileDialog dialog(this);
    QStringList filters;
    filters << "Image files (*.png *.xpm *.jpg)";
    dialog.setNameFilters(filters);
    QString str = dialog.getOpenFileName();
    if (str != QString())
    {
        QImage* img1 = new QImage(str);
        Level* lev1 = new Level(this);
        levels.append(lev1);
        levels[levels.size()-1]->num = levels.size()-1;
        lev1->setImage(img1);
        emit signalNewLabel(QString::number(levels.size()));
    }
}


void levels_1::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    if (GameOn == true)
    {
        maxHorizontalSmesh = 0;
        maxVerticalSmesh = 0;
        for (int i = 0;i<60;i++)
        {
            int metkaHor = 0;
            int metkaVert = 0;
            int j =0;
            while (j != (29))
            {
                if ((levels[currLevel-1]->arrayHor[j][i] >0) && (levels[currLevel-1]->arrayHor[j][i] <61))
                {
                    ++metkaHor;
                }
                if ((levels[currLevel-1]->arrayVert[i][j] >0) && (levels[currLevel-1]->arrayVert[i][j] <61))
                {
                    ++metkaVert;
                }
                j++;
            }
            if (metkaHor > maxHorizontalSmesh)
            {
                maxHorizontalSmesh = metkaHor;
            }
            if (metkaVert > maxVerticalSmesh)
            {
                maxVerticalSmesh = metkaVert;
            }
        }
        for (int i = 0;i<60;i++)
        {
            int metkaHor = 0;
            int metkaVert = 0;
            int j =0;
            while (j != (29))
            {
                if ((levels[currLevel-1]->arrayHor[j][i] >0) && (levels[currLevel-1]->arrayHor[j][i] <61))
                {
                    painter.drawText(mashtab*metkaHor,maxVerticalSmesh*mashtab+mashtab+i*mashtab,QString::number(levels[currLevel-1]->arrayHor[j][i]));
                    ++metkaHor;
                }
                if ((levels[currLevel-1]->arrayVert[i][j] >0) && (levels[currLevel-1]->arrayVert[i][j] <61))
                {
                    short t = levels[currLevel-1]->arrayVert[i][j];
                    painter.drawText(mashtab*maxHorizontalSmesh+i*mashtab,mashtab+metkaVert*mashtab,QString::number(t));
                    ++metkaVert;
                }
                j++;
            }
        }
        //создание "холста"
        for (int i = 0;i<100;i++)
        {
            int j = 0;
            while (j != (100))
            {
                painter.drawRect(i*mashtab,j*mashtab,mashtab,mashtab);
                j++;
            }
        }
        for (int i = 0;i<60;i++)
        {
            int j = 0;
            while (j != (60))
            {
                if (arrayUserPict[i][j] == 0)
                {
                    painter.fillRect(mashtab*maxHorizontalSmesh + i*mashtab,maxVerticalSmesh*mashtab+j*mashtab,mashtab-1,mashtab-1,QColor(200,200,200));
                    painter.drawRect(mashtab*maxHorizontalSmesh + i*mashtab,maxVerticalSmesh*mashtab+j*mashtab,mashtab,mashtab);
                }
                else
                {
                    painter.fillRect(mashtab*maxHorizontalSmesh + i*mashtab,maxVerticalSmesh*mashtab+j*mashtab,mashtab-1,mashtab-1,QColor(0,0,0));
                    painter.drawRect(mashtab*maxHorizontalSmesh + i*mashtab,maxVerticalSmesh*mashtab+j*mashtab,mashtab,mashtab);
                }
                j++;
            }
        }
        //проверка окончания игры
        int summaryScore = 0;
        for (int i = 0; i < 60; ++i) {
            int j = 0;
            //int sum = 0;
            while (j != 60) {
                if (arrayUserPict[i][j] == levels[currLevel-1]->arrayPict[i][j]){
                    summaryScore++;
                }
                j++;
            }
        }
        if (summaryScore == 3600)
        {
            emit signalEndGame(currLevel-1);
        }
    }
    else
    {
        painter.fillRect(0,0,3000,3000,QColor(255,255,255));
    }
    // создание цифр

    //
    //QImage img ("Images_bw/level0.jpg");
    //img.scaledToHeight(2048);
    //img.scaledToWidth(2048);
    //painter.drawImage(0,0,img);
    //painter.drawRect(QRect(0,0,2048,2048));
    //QScrollArea* area1 = new QScrollArea();
    //area1->setWidget(this);
}


void levels_1::keyPressEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_Control)
    {
        if (mashtab > 2)
        {
            mashtab -= 2;
        }
    }
    else if (event->key() == Qt::Key_Shift)
    {
        if (mashtab < 30)
        {
            mashtab += 2;
        }
    }
    this->repaint();
}


void levels_1::mousePressEvent(QMouseEvent *event)
{
        //arrayUserPict[0][0] == true;
        //this->repaint();
        if ((((event->pos().x()- 20*maxHorizontalSmesh)/20) >=0) && (((event->pos().x()- 20*maxHorizontalSmesh)/20) < 60))
        {
            if ((((event->pos().y()- 20*maxVerticalSmesh)/20) >=0) && (((event->pos().y()- 20*maxVerticalSmesh)/20) < 60))
            {
                if (event->button() == Qt::LeftButton)
                {
                arrayUserPict[((event->pos().x()- 20*maxHorizontalSmesh)/20)][((event->pos().y()- 20*maxVerticalSmesh)/20)] = true;
                levels[currLevel-1]->arrayUserVer[((event->pos().x()- 20*maxHorizontalSmesh)/20)][((event->pos().y()- 20*maxVerticalSmesh)/20)] = true;
                this->repaint();
                }
                else if (event->button() == Qt::RightButton)
                {
                    arrayUserPict[((event->pos().x()- 20*maxHorizontalSmesh)/20)][((event->pos().y()- 20*maxVerticalSmesh)/20)] = false;
                    levels[currLevel-1]->arrayUserVer[((event->pos().x()- 20*maxHorizontalSmesh)/20)][((event->pos().y()- 20*maxVerticalSmesh)/20)] = false;
                    this->repaint();
                }
            }
        }
//        if (event->button() == Qt::RightButton)
//        {
//            if (event->modifiers() == Qt::ControlModifier)
//            {
//                if (mashtab > 2)
//                {
//                    mashtab -= 2;
//                }
//            }
//            else if (event->modifiers() == Qt::ShiftModifier)
//            {
//                if (mashtab < 30)
//                {
//                    mashtab += 2;
//                }
//            }
//        }
        this->repaint();
}


void levels_1::keyReleaseEvent(QKeyEvent *event)
{
    if (event->key() == Qt::Key_0)
    {
        if (mashtab > 2)
        {
            mashtab -= 2;
        }
    }
    else if (event->key() == Qt::Key_9)
    {
        if (mashtab < 30)
        {
            mashtab += 2;
        }
    }
    this->repaint();
}


void levels_1::timerEvent(QTimerEvent *event)
{
    if (levels.size() > 0)
    {
        int count = 0;
        for (int i = 0; i < levels.size(); ++i) {
            emit signalNewLabel(QString::number(i+1));
            for (int m = 0; m < 60; ++m) {
                for (int n = 0; n < 60; ++n) {
                    if (levels[i]->arrayUserVer[m][n] == levels[i]->arrayPict[m][n])
                    {
                        count++;
                    }
                }
            }
            if (count == 3600)
            {
                emit signalEndGame(i);
            }
        }
        currLevel = 1;
    }
    killTimer(idtimer);
}
