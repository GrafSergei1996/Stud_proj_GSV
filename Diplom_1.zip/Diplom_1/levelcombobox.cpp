#include "levelcombobox.h"

LevelComboBox::LevelComboBox(QWidget *parent) : QWidget(parent)
{
    CongrBox.setText(QStringLiteral("Вы выиграли!"));
    box = new QComboBox(this);
    mainLayout = new QVBoxLayout(this);
    mainLayout->addWidget(box);
    //this->
    this->repaint();
    //box.show();
    //box->addItem(QStringLiteral("1"));
    //box->
    connect(box,SIGNAL(activated(int)),this,SLOT(emitChangeLevel(int)));
    //connect(box,SIGNAL(currentIndexChanged(int)),this,SLOT(emitChangeLevel(int)));
}

void LevelComboBox::emitChangeLevel(int i)
{
    emit signalLevelChoised(i);
}

void LevelComboBox::slotAddNewItem(QString str)
{
    box->addItem(str);
    //emit signalLevelChoised(str.toInt());
}

void LevelComboBox::slotDeleteAllItems()
{
    box->clear();
}

void LevelComboBox::slotSetIcon(int i)
{
    //const QIcon testIcon = box->itemIcon(i);
    if (box->itemIcon(i).isNull())
    {
        //QMessageBox CongrBox;
        //CongrBox.setText(QStringLiteral("Вы выиграли!"));
        CongrBox.show();
        box->setItemIcon(i,checkIcon);
    }
}


void LevelComboBox::paintEvent(QPaintEvent *event)
{
    //QPainter painter(box);
}
