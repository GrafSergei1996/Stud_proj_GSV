/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.12.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QScrollArea>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "levelcombobox.h"
#include "levels_1.h"

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralWidget;
    QWidget *verticalLayoutWidget;
    QVBoxLayout *verticalLayout;
    QPushButton *buttonNewGame;
    QLabel *label;
    LevelComboBox *widget;
    QPushButton *buttonAddLevel;
    QPushButton *buttonDeleteLevel;
    QScrollArea *scrollArea;
    QWidget *scrollAreaWidgetContents_4;
    levels_1 *widget_2;
    QMenuBar *menuBar;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(1370, 819);
        MainWindow->setMinimumSize(QSize(0, 0));
        centralWidget = new QWidget(MainWindow);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayoutWidget = new QWidget(centralWidget);
        verticalLayoutWidget->setObjectName(QString::fromUtf8("verticalLayoutWidget"));
        verticalLayoutWidget->setGeometry(QRect(990, 0, 261, 171));
        verticalLayout = new QVBoxLayout(verticalLayoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        buttonNewGame = new QPushButton(verticalLayoutWidget);
        buttonNewGame->setObjectName(QString::fromUtf8("buttonNewGame"));

        verticalLayout->addWidget(buttonNewGame);

        label = new QLabel(verticalLayoutWidget);
        label->setObjectName(QString::fromUtf8("label"));
        label->setMaximumSize(QSize(16777215, 30));
        label->setAlignment(Qt::AlignCenter);

        verticalLayout->addWidget(label);

        widget = new LevelComboBox(verticalLayoutWidget);
        widget->setObjectName(QString::fromUtf8("widget"));

        verticalLayout->addWidget(widget);

        buttonAddLevel = new QPushButton(verticalLayoutWidget);
        buttonAddLevel->setObjectName(QString::fromUtf8("buttonAddLevel"));

        verticalLayout->addWidget(buttonAddLevel);

        buttonDeleteLevel = new QPushButton(verticalLayoutWidget);
        buttonDeleteLevel->setObjectName(QString::fromUtf8("buttonDeleteLevel"));

        verticalLayout->addWidget(buttonDeleteLevel);

        scrollArea = new QScrollArea(centralWidget);
        scrollArea->setObjectName(QString::fromUtf8("scrollArea"));
        scrollArea->setGeometry(QRect(170, 0, 811, 661));
        scrollArea->setWidgetResizable(true);
        scrollAreaWidgetContents_4 = new QWidget();
        scrollAreaWidgetContents_4->setObjectName(QString::fromUtf8("scrollAreaWidgetContents_4"));
        scrollAreaWidgetContents_4->setGeometry(QRect(0, 0, 3000, 3000));
        scrollAreaWidgetContents_4->setMinimumSize(QSize(3000, 3000));
        widget_2 = new levels_1(scrollAreaWidgetContents_4);
        widget_2->setObjectName(QString::fromUtf8("widget_2"));
        widget_2->setGeometry(QRect(0, 0, 3000, 3000));
        widget_2->setMinimumSize(QSize(3000, 3000));
        scrollArea->setWidget(scrollAreaWidgetContents_4);
        MainWindow->setCentralWidget(centralWidget);
        menuBar = new QMenuBar(MainWindow);
        menuBar->setObjectName(QString::fromUtf8("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 1370, 21));
        MainWindow->setMenuBar(menuBar);
        mainToolBar = new QToolBar(MainWindow);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        MainWindow->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(MainWindow);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        MainWindow->setStatusBar(statusBar);

        retranslateUi(MainWindow);
        QObject::connect(widget, SIGNAL(signalLevelChoised(int)), widget_2, SLOT(SetLevel(int)));
        QObject::connect(buttonNewGame, SIGNAL(clicked()), widget_2, SLOT(slotGameOn()));
        QObject::connect(buttonAddLevel, SIGNAL(clicked()), widget_2, SLOT(slot1()));
        QObject::connect(widget_2, SIGNAL(signalNewLabel(QString)), widget, SLOT(slotAddNewItem(QString)));
        QObject::connect(buttonDeleteLevel, SIGNAL(clicked()), widget_2, SLOT(slotDeleteLevel()));
        QObject::connect(widget_2, SIGNAL(signalDeleteItems()), widget, SLOT(slotDeleteAllItems()));
        QObject::connect(widget_2, SIGNAL(signalEndGame(int)), widget, SLOT(slotSetIcon(int)));

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QApplication::translate("MainWindow", "MainWindow", nullptr));
        buttonNewGame->setText(QApplication::translate("MainWindow", "\320\235\320\260\321\207\320\260\321\202\321\214 \320\270\320\263\321\200\321\203", nullptr));
        label->setText(QApplication::translate("MainWindow", "\320\222\321\213\320\261\320\265\321\200\320\270\321\202\320\265 \321\203\321\200\320\276\320\262\320\265\320\275\321\214", nullptr));
        buttonAddLevel->setText(QApplication::translate("MainWindow", "\320\224\320\276\320\261\320\260\320\262\320\270\321\202\321\214 \321\203\321\200\320\276\320\262\320\265\320\275\321\214", nullptr));
        buttonDeleteLevel->setText(QApplication::translate("MainWindow", "\320\243\320\264\320\260\320\273\320\270\321\202\321\214 \321\203\321\200\320\276\320\262\320\265\320\275\321\214", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
