#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include "level_1.h"
#include "levels_1.h"
#include <QScrollArea>
namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    bool GameOn;
    int levelNumber;
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_widget_signalLevelChoised(int );

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
