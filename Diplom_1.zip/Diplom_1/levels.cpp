#include "levels.h"

Levels::Levels(QWidget *parent) : QWidget(parent)
{
    //QScrollArea* area1 = new QScrollArea();
    //area1->setWidget(this);
    Level* lev1 = new Level();
    levels.append(lev1);
    QImage* img1 = new QImage(QStringLiteral("Images_bw/level") + QString::number(0) + QStringLiteral(".jpg"));
    levels[0]->setImage(img1);
    levels[0]->num = 0;
    currLevel = 1;
    repaint();
}

void Levels::slotPaint()
{
    repaint();
}


void Levels::mousePressEvent(QMouseEvent *event)
{

}




void Levels::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    int maxHorizontalSmesh = 0;
    int maxVerticalSmesh = 0;
    for (int i = 0;i<60;i++)
    {
        int metkaHor = 0;
        int metkaVert = 0;
        int j =0;
        while (j != (29))
        {
            if ((levels[currLevel-1]->arrayHor[j][i] >0) && (levels[currLevel-1]->arrayHor[j][i] <61))
            {
                ++metkaHor;
            }
            if ((levels[currLevel-1]->arrayVert[j][i] >0) && (levels[currLevel-1]->arrayVert[j][i] <61))
            {
                ++metkaVert;
            }
            j++;
        }
        if (metkaHor > maxHorizontalSmesh)
        {
            maxHorizontalSmesh = metkaHor;
        }
        if (metkaVert > maxVerticalSmesh)
        {
            maxVerticalSmesh = metkaVert;
        }
    }
    for (int i = 0;i<60;i++)
    {
        int metkaHor = 0;
        int metkaVert = 0;
        int j =0;
        while (j != (29))
        {
            if ((levels[currLevel-1]->arrayHor[j][i] >0) && (levels[currLevel-1]->arrayHor[j][i] <61))
            {
                painter.drawText(20*metkaHor,maxVerticalSmesh*20+i*20,QString::number(levels[currLevel-1]->arrayHor[j][i]));
                ++metkaHor;
            }
            if ((levels[currLevel-1]->arrayVert[j][i] >0) && (levels[currLevel-1]->arrayVert[j][i] <61))
            {
                painter.drawText(20*maxHorizontalSmesh+i*20,metkaVert*20,QString::number(levels[currLevel-1]->arrayVert[j][i]));
                ++metkaVert;
            }
            j++;
        }
    }
    //QImage img ("Images_bw/level0.jpg");
    //painter.drawImage(0,0,img);
}
