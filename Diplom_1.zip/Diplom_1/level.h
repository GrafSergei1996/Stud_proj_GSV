#ifndef LEVEL_H
#define LEVEL_H

#include <QWidget>
#include<QImage>
#include<QString>
class Level : public QWidget
{
    QImage enterImage;
    QImage resultImage;
    QImage testImage;
    int num;
    bool arrayPict[60][60];
    short arrayHor[30][60];
    short arrayVert[30][60];
    Q_OBJECT
    void binarization();
    void formArrays();
public:
    explicit Level(QWidget *parent = nullptr);
signals:

public slots:
    //void slotPictureChoise();
};

#endif // LEVEL_H
