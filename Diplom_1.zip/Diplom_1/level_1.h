#ifndef LEVEL_H
#define LEVEL_H

#include <QWidget>
#include<QImage>
#include<QString>
class Level : public QWidget
{
    QImage enterImage;
    QImage resultImage;
    QImage testImage;
    int num;
    bool arrayPict[60][60];
    short arrayHor[30][60];
    short arrayVert[60][30];
    bool arrayUserVer[60][60];
    Q_OBJECT
    void binarization();
    void formArrays();
    friend class Levels;
    friend class levels_1;
public:
    explicit Level(QWidget *parent = nullptr);
    void setImage(QImage*);
    void setNum(int);
signals:

public slots:
    //void slotPictureChoise();
};

#endif // LEVEL_H
