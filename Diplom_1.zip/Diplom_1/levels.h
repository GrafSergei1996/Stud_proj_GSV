#ifndef LEVELS_H
#define LEVELS_H

#include <QWidget>
#include "level_1.h"
#include<QScrollArea>
#include <QPixmap>
#include <QPainter>
class Levels : public QWidget
{
    QVector<Level*> levels;
    int currLevel;
    Q_OBJECT
public:
    explicit Levels(QWidget *parent = nullptr);

signals:

public slots:
    void slotPaint();
    // QWidget interface
protected:
    virtual void mousePressEvent(QMouseEvent *event);

    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);
};

#endif // LEVELS_H
