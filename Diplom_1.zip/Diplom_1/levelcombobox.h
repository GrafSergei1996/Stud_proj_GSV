#ifndef LEVELCOMBOBOX_H
#define LEVELCOMBOBOX_H

#include <QWidget>
#include <QComboBox>
#include<QVBoxLayout>
#include <QIcon>
#include <QMessageBox>
class LevelComboBox : public QWidget
{
    Q_OBJECT
    QVBoxLayout* mainLayout;
    QMessageBox CongrBox;
    QComboBox* box;
    const QIcon checkIcon = QIcon("Check.ico");
public:
    explicit LevelComboBox(QWidget *parent = nullptr);

signals:
    void signalLevelChoised(int);
    //void signalIsInit(bool);

public slots:
    void emitChangeLevel(int);
    void slotAddNewItem(QString);
    void slotDeleteAllItems();
    void slotSetIcon(int);
    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);
};

#endif // LEVELCOMBOBOX_H
