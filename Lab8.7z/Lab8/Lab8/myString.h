#pragma once
#include<iostream>
#include"Counter.h"
class MyString
{
    Counter* m_C;	//������-���� ������
public:
	MyString(const char* pc1 = nullptr);
	MyString(const MyString&);
	MyString(MyString&&);
	~MyString();
	//void SetNewString(const char*);
	//void GetString(char*);
	const char* GetString1() const;
	/*void AddString(const char*);*/
	MyString& operator= (const MyString&);
	MyString& operator= (const char*);
	MyString& operator= (MyString&&);
	MyString& operator+= (const MyString&);
	MyString operator+ (const const MyString&) const;
	friend std::ostream& operator << (std::ostream& out, MyString&);
	static void PrintAllStrings();
	static void ChangeRegister();
	static void PrintAlphabet();
	char FirstChar() const;
};
MyString AddString(const char*, ...);
bool FirstChAa(const MyString&);
