#include"Point.h"
Point::Point(int x, int y)
{
	m_px = x;
	m_py = y;
}
Point& Point::operator+=(const Point& p1)
{
	m_px += p1.m_px;
	m_py += p1.m_py;
	return *this;
}

Point& Point::operator+=(int a)
{
	m_px += a;
	m_py += a;
	return *this;
}
Point Point::operator+(const Point& a) const
{
	Point b;
	b.m_px = m_px + a.m_px;
	b.m_py = m_py + a.m_py;
	return b;
}

Point Point::operator+(const int a) const
{
	Point b;
	b.m_px = m_px + a;
	b.m_py = m_py + a;
	return b;
	// TODO: �������� ����� �������� return
}

std::ostream& operator<<(std::ostream& out, Point p)
{
	out << p.GetPointX() << ":" << p.GetPointY() << '\n';
	return out;
}

std::ostream& operator<<(std::ostream& out, Point* pp)
{
	out << pp->GetPointX() << ":" << pp->GetPointY() << '\n';
	return out;
}

std::ostream& operator<<(std::ostream& out, Point& p)
{
	out << p.GetPointX() << ":" << p.GetPointY() << '\n';
	return out;
}

Point operator-(const int b, const Point& a)
{
	int ax, ay;
	a.GetPoint(ax, ay);
	return Point(-ax + b, -ay + b);
}

Point operator-(const Point& a, const Point& b)
{
	int ax, ay, bx, by;
	a.GetPoint(ax, ay);
	b.GetPoint(bx, by);
	return Point(ax - bx, ay - by);
}

Point operator-(const Point& a, const int b)
{
	int ax, ay;
	a.GetPoint(ax, ay);
	return Point(ax - b, ay - b);
}
void Point::GetPoint(int& x, int& y) const
{
	x = m_px;
	y = m_py;
}

void Point::SetPoint(int x, int y)
{
	m_px = x;
	m_py = y;
}
Point Point::operator-()
{
	return Point(-m_px, -m_py);
}

int Point::GetPointX() const
{
	return m_px;
}

int Point::GetPointY() const
{
	return m_py;
}

bool Point::operator<(const Point& pt) const
{
	return ((m_px*m_px + m_py*m_py) < (pt.m_px*pt.m_px + pt.m_py* pt.m_py));
}

bool Point::operator==(const Point& pt) const
{
	return ((m_px == pt.m_px) && ( m_py ==  pt.m_py));
}

bool Neg(const Point p)
{
	return ((p.GetPointX() < 0) || (p.GetPointY() < 0));
}

