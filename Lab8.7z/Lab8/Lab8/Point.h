#pragma once
#include<iostream>
class Point 
{
	int m_px;
	int m_py;
public:
	Point(int = 0, int=0);
	Point& operator+= (const Point&);
	Point& operator+= (int);
	Point operator+ (const Point&) const;
	Point operator+ (const int) const;
	void GetPoint(int&, int&) const;
	void SetPoint(int, int);
	Point operator- ();
	int GetPointX() const;
	int GetPointY() const;
	bool operator < (const Point&) const;
	bool operator == (const Point&) const;
	friend std::ostream& operator << (std::ostream&, Point);
	friend std::ostream& operator << (std::ostream&,Point*);
	friend std::ostream& operator << (std::ostream&, Point&);
};
Point operator- (const int, const Point&);
Point operator- (const Point&, const Point&);
Point operator- (const Point&, const int);
bool Neg(const Point);
