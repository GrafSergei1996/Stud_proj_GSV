#include<tchar.h>
#include"myString.h"
#include<iostream>
#define	  stop __asm nop

int _tmain(int argc, _TCHAR* argv[])
{
	MyString a("AAA");
	MyString b("BBB");
	MyString c("CCC");
	MyString d("DDD");
	MyString e(a);
	d = a;
	d += a;
	d = a + b + c + b;
	const char* pc = d.GetString1();
	std::cout << d << '\n';
	MyString::PrintAllStrings();
	MyString::ChangeRegister();
	MyString::PrintAlphabet();


	return 0;
}