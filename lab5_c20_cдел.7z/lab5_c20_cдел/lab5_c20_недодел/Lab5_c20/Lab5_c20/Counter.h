#pragma once
class Counter
{
	friend class MyString;
	char* m_pStr;
	size_t m_owners;
	Counter* pNext;
	Counter(const char*);
	~Counter();
	void AddUser();
	void RemoveUser();
	static Counter* Cmp(const char*);
//public:
	static Counter* pHead;
	static unsigned int m_curCounters;
};
