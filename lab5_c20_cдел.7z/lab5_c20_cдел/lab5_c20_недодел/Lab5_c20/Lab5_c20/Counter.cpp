#include "Counter.h"
#include<iostream>
unsigned int Counter::m_curCounters = 0;
Counter* Counter::pHead = nullptr;
Counter::Counter(const char* s) :m_owners(1)
{
	size_t n = strlen(s) + 1;
	m_pStr = new char[n];
	strcpy(m_pStr, s);
	m_curCounters++;
	
	if (pHead != nullptr)
	{
		this->pNext = pHead->pNext;
		pHead->pNext = this;
	}
	else
	{
		pHead = this;
		pHead->pNext = this;
	}
}

Counter::~Counter()
{
	delete[] m_pStr;
	//m_curCounters--;
}

void Counter::AddUser()
{
	m_owners++;
}

void Counter::RemoveUser()
{
	m_owners--;
	if (m_owners == 0)
	{
		m_curCounters--;
		Counter* p = this->pNext;
		delete this;
		pHead->pNext = p;
	}
}

Counter* Counter::Cmp(const char* c)
{
	Counter* p = Counter::pHead;
	for (size_t i = 0; i < Counter::m_curCounters; i++)
	{
		if (!strcmp(p->m_pStr, c))
		{
			p->AddUser();
			return p;
		}
		p = p->pNext;
	}
	return new Counter(c);
}

//Counter& Counter::operator=(const Counter& c)
//{
//
//	// TODO: insert return statement here
//}
