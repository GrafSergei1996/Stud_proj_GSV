#pragma once
//#include "MyStack2.h"
#include<iostream>
#include "MyStack2.h"
//////////////////////////////
template<typename T>
MyList<T>::CounterML::CounterML(const T& t1,CounterML* pc) : t(t1)
{
	//����� ������������ ��� �������������;
//����� ���� � �������
	{
		this->pNext = pc;
		pc= this;
	}
}

//template<typename T>
//MyList<T>::CounterML::CounterML(CounterML* pc)
//{
//	//{//����� ������������ ��� �������������;
//
//	if (MyList<T>::pml != nullptr)//����� ���� � �������
//	{
//		this->pNext = MyList<T>::pml->pNext;
//		MyList<T>::pml->pNext = this;
//	}
//	else
//	{
//		MyList<T>::pml = this;
//		MyList<T>::pml->pNext = this;
//	}
//}

//template<typename T>
//MyList<T>::CounterML::~CounterML()
//{
//	if (pHead == this) //�� ������� ������ �� ����. ��-�, ���� ��������� � ������ ������.
//	{
//		pHead = pHead->pNext;
//	}
//	else
//	{
//		CounterML* p = pHead;
//		while (p->pNext != this)
//		{
//			p = p->pNext;
//		}
//		p->pNext = this->pNext;
//	}
//	m_curCounters--;
//}
//
//template<typename T>
//void MyList<T>::CounterML::AddUser()
//{
//	m_owners++;
//}
//
//template<typename T>
//void MyList<T>::CounterML::RemoveUser()
//{
//	m_owners--;
//	if (m_owners == 0)
//	{
//		delete this;
//	}
//}
//
//template<typename T>
//typename MyList<T>::CounterML* MyList<T>::CounterML::Cmp(T t1)
//{
//	CounterML* p = pHead;
//	for (size_t i = 0; i < CounterML<T>::m_curCounters; i++)
//	{
//		if (p->t == t1)
//		{
//			p->AddUser();
//			return p;
//		}
//		p = p->pNext;
//	}
//	return new CounterML(t1);
//}
//////////////////////////////////////////

template<typename T>
MyList<T>::MyList()
{
	pml = nullptr;
}

template<typename T>
MyList<T>::~MyList()
{
	CounterML* p = pml;
	while (p != nullptr)
	{
		CounterML* p1 = p->pNext;
		delete p;
		p = p1;
	}
}

template<typename T>
MyList<T>::MyList(const MyList& ml)
{
	CounterML* p = ml.pml;
	pml = nullptr;
	while (p != nullptr)
	{
		pml = new CounterML(p->t, pml);
		p = p->pNext;
	}
}

//template<typename T>
//MyList<T>::MyList(const T& t1)
//{
//	pml = MyList<T>::CounterML::Cmp(T(t1));
//}

template<typename T>
MyList<T>::MyList(MyList&& ml)
{
	ml = ml.pml;
	ml.pml = nullptr;
}

template<typename T>
void MyList<T>::push(const T& t1)
{
	pml = new CounterML(t1,pml);
	//CounterML* p2 = p1;
	//while (p2->pNext != nullptr)
	//{
	//	p2 = p2->pNext;

	//}
	//pml = p1;
	//p2->pNext = nullptr;
	//CounterML<T>::pHead->pNext = pml->pNext;
	//p2->pNext = pml->pNext;
	//pml->pNext = p;
	//pml = p;
}

template<typename T>
void MyList<T>::pop()
{
	CounterML* p = pml->pNext;
	delete pml;
	pml = p;
}

template<typename T>
MyList<T>& MyList<T>::operator=(MyList&& ml)
{
	pml = ml.pml;
	ml.pml = nullptr;
	return *this;
}

template<typename T>
MyList<T>& MyList<T>::operator=(const MyList& ml)
{
	CounterML* p1 = pml;
	CounterML* p2 = ml.pml;
	unsigned int n = 0;
	while ((p1 != nullptr) && (p2 != nullptr))
	{
		n++;
		p1 = p1->pNext;
		p2 = p2->pNext;
	}
	if (p1 == nullptr)
	{
		while (p2 != nullptr)
		{
			p1 = new CounterML(p2->t, p1);
			p2 = p2->pNext;
			p1 = p1->pNext;
		}
	}
	if (p2 == nullptr)
	{
		while (p1 != nullptr)
		{
			CounterML* p3 = p1->pNext;
			delete p1;
			p1 = p3;
		}
	}
	p1 = pml;
	p2 = ml.pml;
	for (size_t i = 0; i < n; i++)
	{
		p1->t = p2->t;
		p2 = p2->pNext;
		p1 = p1->pNext;
	}
	return *this;
}

//template<typename T>
//MyList<T>& MyList<T>::operator=(const T& t1)
//{
//	MyList<T> ml = MyList<T>(t1);
//	pml->RemoveUser();
//	*this = ml;
//	return *this;
//}

template<typename T>
void MyList<T>::PrintStringsInv()
{
	CounterML* p = pml;
	while (p != nullptr)
	{
		std::cout << p->t;
		p = p->pNext;
	}
}

template<typename T>
void MyList<T>::PrintStrings()
{
	CounterML* p = pml;
	int n = 0;
	while (p != nullptr)
	{
		n++;
		p = p->pNext;
	}
	p = pml;
	CounterML** ppc = new CounterML * [n];
	for (size_t i = 0; i < n; i++)
	{
		ppc[i] = p;
		p = p->pNext;
	}
	for (int i = n-1; i > -1; i--)
	{
		std::cout << ppc[i]->t;
	}
	delete [] ppc;
}

template<typename T>
std::ostream& operator<<(std::ostream& out, const MyList<T>& ml)
{
	out << ml.pml->t;
	return out;
}
