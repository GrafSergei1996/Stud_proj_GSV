//#include"MyStack.h"
template <typename T, size_t n>
MyArray<T,n>::MyArray()
{
	for (size_t i = 0; i < n; i++)
	{
		ar[i] = T();
	}
}

template<typename T, size_t n> 
MyArray<T, n>::MyArray(const MyArray& mr1)
{
	for (size_t i = 0; i < n; i++)
	{
		ar[i] = T(mr1[i]);
	}
	count = mr1.count;
}

template<typename T, size_t n>
MyArray<T, n>::MyArray(MyArray&& mr1)
{
	ar = mr1;
	mr1 = nullptr;
}

template<typename T, size_t n>
MyArray<T, n>::~MyArray()
{
	for (size_t i = 0; i < n; i++)
	{
		ar[i] = ~T();
	}
}

template<typename T, size_t n>
void MyArray<T, n>::push(T& t)
{
	if (count == n)
	{
		return;
	}
	else
	{
		T tmp;
		if (t != tmp)
		{
			ar[count] = t;
			count++;
		}
	}
}

template<typename T, size_t n>
void MyArray<T, n>::pop()
{
	if (count == 0)
	{
		return;
	}
	else
	{
		for (size_t i = 0; i < count-1; i++)
		{
			ar[i] = ar[i + 1];
		}
		ar[count] = T();
	}
}

template<typename T, size_t n>
T& MyArray<T, n>::operator[](int ind)
{
	for (size_t i = 0; i < count; i++)
	{
		if (ind == i)
		{
			return ar[i];
		}
	}
}


