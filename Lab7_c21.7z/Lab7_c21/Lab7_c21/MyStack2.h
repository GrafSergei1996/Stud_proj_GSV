#pragma once
#include<iostream>
template <typename T> 
class MyList
{
	class CounterML
	{
		friend class MyList<T>;
		T t;
		//size_t m_owners;
		CounterML* pNext;
		CounterML(const T&, CounterML*);
		/*CounterML(CounterML*);*/
//		~CounterML();
		//void AddUser();
		//void RemoveUser();
		//static CounterML* Cmp(T);
		////public:
		//static CounterML* pHead;
		//static unsigned int m_curCounters;
		//friend std::ostream& operator << (std::ostream&, const MyList&);
	};
	CounterML* pml;
public:
	MyList();
	~MyList();
	MyList(const MyList&);
	//MyList(const T&);
	MyList(MyList&&);
	void push(const T&);
	void pop();
	MyList& operator = (MyList&&);
	MyList& operator = (const MyList&);
	//MyList& operator = (const T&);
	friend std::ostream& operator << (std::ostream&, const MyList&);
	void PrintStringsInv();
	void PrintStrings();
};
#include"MyStack3.h"


