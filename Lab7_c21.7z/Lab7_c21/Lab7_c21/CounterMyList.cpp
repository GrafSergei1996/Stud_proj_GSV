#include"CounterMyList.h"
#include"MyStack2.h"
#include<tchar.h>

