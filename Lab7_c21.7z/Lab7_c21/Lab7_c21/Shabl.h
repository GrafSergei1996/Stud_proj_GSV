#pragma once
#include<iostream>
#include"MyString.h"
template <typename T> void Swap(T&, T&);

template<typename T>
inline void Swap(T& a, T& b)
{
	T tmp = a;
	a = b;
	b = std::move(tmp);
}

