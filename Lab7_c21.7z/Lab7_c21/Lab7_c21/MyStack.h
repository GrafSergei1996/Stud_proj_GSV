#pragma once
template <typename T, size_t n> 
class MyArray
{
	T ar[n];
	size_t count = 0;
public:
	//MyArray();
	//MyArray(const MyArray&);
	//MyArray(MyArray&&);
	//~MyArray();
	void push(const T);
	void pop();
	T& operator [] (int);
};
#include"MyArray.h"







