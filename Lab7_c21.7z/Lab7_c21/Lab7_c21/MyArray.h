#pragma once
#include<iostream>
#include<string>
//#include"MyStack.h"
//template <typename T, size_t n>
//MyArray<T, n>::MyArray()
//{
//	for (size_t i = 0; i < n; i++)
//	{
//		ar[i] = T();
//	}
//}
//
//template<typename T, size_t n>
//MyArray<T, n>::MyArray(const MyArray& mr1)
//{
//	for (size_t i = 0; i < n; i++)
//	{
//		ar[i] = T(mr1[i]);
//	}
//	count = mr1.count;
//}
//
//template<typename T, size_t n>
//MyArray<T, n>::MyArray(MyArray&& mr1)
//{
//	ar = mr1;
//	mr1 = nullptr;
//}
//
//template<typename T, size_t n>
//MyArray<T, n>::~MyArray()
//{
//	//for (size_t i = 0; i < n; i++)
//	//{
//	//	ar[i] = ~T();
//	//}
//}

template<typename T, size_t n>
void MyArray<T, n>::push(const T t)
{
	try 
	{
		count = n;
		throw 1;
	}
	catch (int a)
	{
		setlocale(LC_ALL, "Rus");
		std::cout << "������������ �������" << '\n';
		return;
	}
	this->ar[count] = t;
	count++;
}

template<typename T, size_t n>
void MyArray<T, n>::pop()
{
	try
	{
		count = 0;
		throw 1;
	}
	catch (int a)
	{
		setlocale(LC_ALL, "Rus");
		std::cout << "������ ������" << '\n';
		return;
	}
		//for (size_t i = 0; i < count - 1; i++)
		//{
		//	ar[i] = ar[i + 1];
		//}
		ar[count-1] = T();
		count--;
}

template<typename T, size_t n>
T& MyArray<T, n>::operator[](int ind)
{
	for (size_t i = 0; i < count; i++)
	{
		if (ind == i)
		{
			return ar[i];
		}
	}
}
