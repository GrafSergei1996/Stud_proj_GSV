#include "MyStack2.h"
#include<iostream>
//////////////////////////////
template<typename T>
typename MyList<T>::CounterML* MyList<T>::CounterML::pHead = nullptr;
template<typename T>
unsigned int MyList<T>::CounterML::m_curCounters = 0;
template<typename T>
MyList<T>::CounterML::CounterML(const T& t1):m_owners(1), t(t1)
{
	//{//����� ������������ ��� �������������;
	m_curCounters++;

	if (pHead != nullptr)//����� ���� � �������
	{
		this->pNext = pHead->pNext;
		pHead->pNext = this;
	}
	else
	{
		pHead = this;
		pHead->pNext = this;
	}
}

template<typename T>
MyList<T>::CounterML::CounterML() :m_owners(1)
{
	//{//����� ������������ ��� �������������;
	m_curCounters++;

	if (pHead != nullptr)//����� ���� � �������
	{
		this->pNext = pHead->pNext;
		pHead->pNext = this;
	}
	else
	{
		pHead = this;
		pHead->pNext = this;
	}
}

template<typename T>
MyList<T>::CounterML::~CounterML()
{
		if (pHead == this) //�� ������� ������ �� ����. ��-�, ���� ��������� � ������ ������.
	{
		pHead = pHead->pNext;
	}
	else
	{
		CounterML* p = pHead;
		while (p->pNext != this)
		{
			p = p->pNext;
		}
		p->pNext = this->pNext;
	}
	m_curCounters--;
}

template<typename T>
void MyList<T>::CounterML::AddUser()
{
	m_owners++;
}

template<typename T>
void MyList<T>::CounterML::RemoveUser()
{
	m_owners--;
	if (m_owners == 0)
	{
		delete this;
	}
}

template<typename T>
typename MyList<T>::CounterML* MyList<T>::CounterML::Cmp(T t1)
{
	CounterML* p = pHead;
	for (size_t i = 0; i < CounterML<T>::m_curCounters; i++)
	{
		if (p->t == t1)
		{
			p->AddUser();
			return p;
		}
		p = p->pNext;
	}
	return new CounterML (t1);
}
//////////////////////////////////////////

template<typename T>
MyList<T>::MyList()
{
	pml = MyList<T>::CounterML::Cmp(T());
}

template<typename T>
MyList<T>::~MyList()
{
	if (pml != nullptr)
	{
		pml->RemoveUser();
	}
}

template<typename T>
MyList<T>::MyList(const MyList& ml)
{
	pml = ml.pml;
	if (pml != nullptr)
	{
		pml->AddUser();
	}
}

template<typename T>
MyList<T>::MyList(const T& t1)
{
	pml = MyList<T>::CounterML::Cmp(T(t1));
}

template<typename T>
MyList<T>::MyList(MyList&& ml)
{
	ml = ml.pml;
	ml.pml = nullptr;
}

template<typename T>
void MyList<T>::push(const T& t1)
{
	pml = new CounterML(t1);
	CounterML* p = CounterML::pHead;
	while (p->pNext == CounterML::pHead)
	{
		p = p->pNext;
	}
	//CounterML<T>::pHead->pNext = pml->pNext;
	p->pNext = pml;
	pml->pNext = CounterML::pHead;
}

template<typename T>
void MyList<T>::pop()
{
	CounterML* p = CounterML::pHead;
	while (p->pNext == CounterML::pHead)
	{
		p = p->pNext;
	}
	delete p;
}

template<typename T>
MyList<T>& MyList<T>::operator=(MyList&& ml)
{
	pml->RemoveUser();
	pml = ml.pml;
	pml = nullptr;
	return *this;
}

template<typename T>
MyList<T>& MyList<T>::operator=(const MyList& ml)
{
	if (pml != ml.pml)
	{
		if (pml != nullptr)
		{
			pml->RemoveUser();
		}
		pml = ml.pml;
		if (ml.pml != nullptr)
		{
			pml->AddUser();
		}
	}
	return *this;
}

template<typename T>
MyList<T>& MyList<T>::operator=(const T& t1)
{
	MyList<T> ml = MyList<T>(t1);
	pml->RemoveUser();
	*this = ml;
	return *this;
}

template<typename T>
void MyList<T>::PrintStrings()
{
	CounterML* p = CounterML::pHead;
	for (size_t i = 0; i < CounterML::m_curCounters; i++)
	{
		std::cout << p->t;
		p = p->pNext;
	}
}

template<typename T>
std::ostream& operator<<(std::ostream& out, const MyList<T>& ml)
{
	out << ml.pml->t;
	return out;
}
