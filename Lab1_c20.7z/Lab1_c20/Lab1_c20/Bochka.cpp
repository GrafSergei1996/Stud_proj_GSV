#include "Bochka.h"
#include<iostream>
int Bochka::Perelivanie(Bochka& istok, double dolya)
{
	int n = 0;
	if (m_spirt < dolya)
	{
		while (m_spirt <= dolya)
		{
			istok.m_volume = istok.m_volume + 1;
			istok.m_spirt = (istok.m_spirt* (istok.m_volume - 1) + m_spirt)/istok.m_volume;
			m_spirt = (m_spirt*(m_volume-1) + istok.m_spirt)/m_volume;
			istok.m_spirt = (istok.m_spirt*istok.m_volume - istok.m_spirt)/(istok.m_volume-1);
			istok.m_volume = istok.m_volume - 1;
			std::cout << m_spirt << ';' << istok.m_spirt << '\n';
			++n;
		}
		return n;
	}
	else
	{
		while (m_spirt >= dolya)
		{
			istok.m_volume = istok.m_volume + 1;
			istok.m_spirt = (istok.m_spirt * (istok.m_volume - 1) + m_spirt) / istok.m_volume;
			m_spirt = (m_spirt * (m_volume - 1) + istok.m_spirt) / m_volume;
			istok.m_spirt = (istok.m_spirt * istok.m_volume - istok.m_spirt) / (istok.m_volume - 1);
			istok.m_volume = istok.m_volume - 1;
			std::cout << m_spirt << ';' << istok.m_spirt << '\n';
			++n;
		}
		return n;
	}
}

void Bochka::Set(double volume, double spirt)
{
	m_volume = volume;
	m_spirt = spirt;
}

void Bochka::Get(double& volume, double& spirt)
{
	volume = m_volume;
	spirt = m_spirt;
}
