#include "myRect.h"

Rect::Rect(int left, int right, int top, int bottom)
{
	m_left = left;
	m_right = right;
	m_top = top;
	m_bottom = bottom;
	Swap(m_left, m_right);
	Swap(m_top, m_bottom);
}

void Rect::InflateRect(int dl, int dr, int dt, int db)
{
	m_left = m_left - dl;
	m_right = m_right + dr;
	m_top = m_top - dt;
	m_bottom = m_bottom + db;
	Swap(m_left, m_right);
	Swap(m_top, m_bottom);
}

void Swap(int& a, int& b)
{
	if (a > b)
	{
		int tmp = a;
		a = b;
		b = tmp;
	}
}

Rect::Rect(const Rect& other)
{
	m_left = other.m_left;
	m_right = other.m_right;
	m_top = other.m_top;
	m_bottom = other.m_bottom;
}

void Rect::InflateRect(int dl, int dt)
{
	m_right = m_right + dl;
	m_left = m_left - dl;
	m_top = m_top - dt;
	m_bottom = m_bottom + dt;
	Swap(m_left, m_right);
	Swap(m_top, m_bottom);
}

void Rect::SetAll(int left, int right, int top, int bottom)
{
	m_left = left;
	m_right = right;
	m_top = top;
	m_bottom = bottom;
	Swap(m_left, m_right);
	Swap(m_top, m_bottom);
}

void Rect::GetAll(int& left, int& right, int& top, int& bottom) const
{
	left = m_left;
	right = m_right;
	top = m_top;
	bottom = m_bottom;
}

void Rect::BoundingRect(const Rect& r1, const Rect& r2) // �� ������ �����, �.�. �� ����� ��������� �����
{// ����� �������� ����� �������� � ���������, �.�. ��� ����� ������
	if (r1.m_left > r2.m_left)
	{
		m_left = r2.m_left;
	} else m_left = r1.m_left;
	if (r1.m_right > r2.m_right)
	{
		m_right = r2.m_right;
	}
	else m_right = r1.m_right;
	if (r1.m_top > r2.m_top)
	{
		m_top = r2.m_top;
	}
	else m_top = r1.m_top;
	if (r1.m_bottom > r2.m_bottom)
	{
		m_bottom = r2.m_bottom;
	}
	else m_bottom = r1.m_bottom;
}

Rect BoundingRect(Rect r1, Rect r2)
{
	int r1l, r1r, r1t, r1b, r2l, r2r, r2t, r2b;
	r1.GetAll(r1l, r1r, r1t, r1b);
	r2.GetAll(r2l, r2r, r2t, r2b);
	Swap(r1l, r2l);
	Swap(r2r, r1r);
	Swap(r1t, r2t);
	Swap(r2b, r1b);
	Rect returnRect(r1l, r1r, r1t, r1b);
	return  returnRect;
}

Rect BoundingRect2(const Rect& rr1, const Rect& rr2)
{
	int r1l, r1r, r1t, r1b, r2l, r2r, r2t, r2b;
	rr1.GetAll(r1l, r1r, r1t, r1b);
	rr2.GetAll(r2l, r2r, r2t, r2b);
	Swap(r1l, r2l);
	Swap(r2r, r1r);
	Swap(r1t, r2t);
	Swap(r2b, r1b);
	Rect returnRect(r1l, r1r, r1t, r1b);
	return  returnRect;
}