#pragma once
class Bochka {
	double m_volume;
	double m_spirt;
public:
	int Perelivanie(Bochka&, double);
	void Set(double, double);
	void Get(double&, double&);
};