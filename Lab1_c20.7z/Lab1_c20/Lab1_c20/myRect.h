#pragma once
class Rect{
	int m_left, m_right, m_top, m_bottom;
public:
	// �����������
	Rect(int left = 0, int right = 0, int top = 0, int bottom = 0);
	void InflateRect(int , int , int , int );
	Rect(const Rect& other);
	void InflateRect(int d1 = 1, int d2 = 1);
	void SetAll(int , int, int, int );
	void GetAll(int&, int&, int&, int&) const;
	void BoundingRect(const Rect& r1, const Rect& r2);
};
void Swap(int& a, int& b);
Rect BoundingRect(Rect, Rect);
Rect BoundingRect2(const Rect&, const Rect&);