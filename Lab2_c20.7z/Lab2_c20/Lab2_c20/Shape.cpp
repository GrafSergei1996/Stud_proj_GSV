#include "Shape.h"
#include <tchar.h>
#include<iostream>
Shape::Shape(color col)
{
	m_col = col;
	//printf("Now I am in Shape's constructor! \n");
}

void Shape::WhereAmI() const
{
	printf("Now I am in class Shape \n");
}

Shape::~Shape() 
{
	printf("Now I am in Shape's destructor! \n");
}

void Shape::WhereAmI_Virtual() const
{
	printf("Now I am in class Shape \n");
}

Rect::Rect(int left, int right, int top, int bottom, color col):Shape(col)
{
	m_left = left;
	m_right = right;
	m_top = top;
	m_bottom = bottom;
	//printf("Now I am in Rect's constructor! \n");
	
}

void Rect::WhereAmI() const
{
	printf("Now I am in class Rect \n");
}

Rect::~Rect()
{
	printf("Now I am in Rect's destructor! \n");
}

void Rect::WhereAmI_Virtual() const
{
	printf("Now I am in class Rect \n");
}

void Rect::Inflate(int dl)
{
	m_right = m_right + dl;
	m_left = m_left - dl;
	m_top = m_top - dl;
	m_bottom = m_bottom + dl;
}

void Rect::Get(int l, int r, int t , int b)
{
	l = m_left;
	r = m_right;
	t = m_top;
	b = m_bottom;
}

Circle::Circle(int center_x, int center_y, int rad, color col):Shape(col)
{
	m_center_x = center_x;
	m_center_y = center_y;
	m_rad = rad;
	//printf("Now I am in Clrcle's constructor! \n");
}

Circle::Circle(Rect& rect):Shape(rect)
{
	int l, r, t, b;
	rect.Get(l, r, t, b);
	m_center_x = (l + r) / 2;
	m_center_y = (t + b) / 2;
	if ((t + b) < (l + r))
	{
		m_rad = (t + b) / 2;
	}
	else (r + l) / 2;
}

void Circle::WhereAmI() const
{
	printf("Now I am in class Circle \n");
}

Circle::~Circle()
{
	//printf("Now I am in Circle's destructor! \n");
}

void Circle::WhereAmI_Virtual() const
{
	printf("Now I am in class Circle \n");
}

void Circle::Inflate(int size)
{


	m_rad += size;
}
