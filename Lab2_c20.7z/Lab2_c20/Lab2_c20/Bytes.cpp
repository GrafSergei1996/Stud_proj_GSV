#include<iostream>
#include "Bytes.h"

void Bin::Show()
{
	std::cout << static_cast<size_t>(m_bin7);
	std::cout << static_cast<size_t>(m_bin6);
	std::cout << static_cast<size_t>(m_bin5);
	std::cout << static_cast<size_t>(m_bin4);
	std::cout << static_cast<size_t>(m_bin3);
	std::cout << static_cast<size_t>(m_bin2);
	std::cout << static_cast<size_t>(m_bin1);
	std::cout << static_cast<size_t>(m_bin0);
	std::cout << '\n';
}

void Bin::ShowPos(int pos)
{
	switch (pos)
	{
	case 1:
	{
		std::cout << static_cast<size_t>(m_bin0) << '\n';
		break;
	}
	case 2:
	{
		std::cout << static_cast<size_t>(m_bin1) << '\n';
		break;
	}
	case 3:
	{
		std::cout << static_cast<size_t>(m_bin2) << '\n';
		break;
	}
	case 4:
	{
		std::cout << static_cast<size_t>(m_bin3) << '\n';
		break;
	}
	case 5:
	{
		std::cout << static_cast<size_t>(m_bin4) << '\n';
		break;
	}
	case 6:
	{
		std::cout << static_cast<size_t>(m_bin5) << '\n';
		break;
	}
	case 7:
	{
		std::cout << static_cast<size_t>(m_bin6) << '\n';
		break;
	}
	case 8:
	{
		std::cout << static_cast<size_t>(m_bin7) << '\n';
		break;
	}
	}
	
}

void Bin::Edit(int pos, int val)
{
	switch (pos)
	{
	case 1:
	{
		m_bin0 = val;
		break;
	}
	case 2:
	{
		m_bin1 = val;
		break;
	}
	case 3:
	{
		m_bin2 = val;
		break;
	}
	case 4:
	{
		m_bin3 = val;
		break;
	}
	case 5:
	{
		m_bin4 = val;
		break;
	}
	case 6:
	{
		m_bin5 = val;
		break;
	}
	case 7:
	{
		m_bin6 = val;
		break;
	}
	case 8:
	{
		m_bin7 = val;
		break;
	}
	}
}

void Hex::Show()
{
	std::cout << std::hex << static_cast<size_t>(m_hex1);
	std::cout << std::hex << static_cast<size_t>(m_hex0);
		std::cout << '\n';
}

void Hex::ShowPos(int pos)
{
	switch (pos)
	{
	case 1:
	{
		std::cout << std::hex << static_cast<size_t>(m_hex0) << '\n';
		break;
	}
	case 2:
	{
		std::cout << std::hex << static_cast<size_t>(m_hex1) << '\n';
		break;
	}
	}
}

void Hex::Edit(int pos, int val)
{
	switch (pos)
	{
	case 1:
	{
		m_hex0 = val;
		break;
	}
	case 2:
	{
		m_hex1 = val;
		break;
	}
	}
}

void Oct::Show()
{
	std::cout << static_cast<size_t>(m_oct2);
	std::cout << static_cast<size_t>(m_oct1);
	std::cout << static_cast<size_t>(m_oct0);
	std::cout << '\n';
}

void Oct::ShowPos(int pos)
{
	switch (pos)
	{
	case 1:
	{
		std::cout << static_cast<size_t>(m_oct0) << '\n';
		break;
	}
	case 2:
	{
		std::cout << static_cast<size_t>(m_oct1) << '\n';
		break;
	}
	case 3:
	{
		std::cout << static_cast<size_t>(m_oct2) << '\n';
		break;
	}
	}
}

void Oct::Edit(int pos, int val)
{
	switch (pos)
	{
	case 1:
	{
		m_oct0 = val;
		break;
	}
	case 2:
	{
		m_oct1 = val;
		break;
	}
	case 3:
	{
		if (val < 4)
		{
			m_oct1 = val;
		}
		else m_oct1 = 3;
		break;
	}
	}
}

void Bytes::ShowDec()
{
	std::cout <<std::dec << static_cast<size_t>(m_dec) << '\n';
}

void Bytes::ShowChar()
{
	//if ((m_dec < 127) && (m_dec > 31))
	//{
		std::cout << m_dec << '\n';
	//}
}
