#pragma once
enum color {RED,GREEN,BLUE,WHITE,BLACK};
class Shape
{
protected:
	color m_col;
public:
	Shape(color = BLACK);
	//void GetColor(color);
	//void SetColor(color);
	void WhereAmI()  const;
	virtual ~Shape();
	virtual void WhereAmI_Virtual() const;
	virtual void Inflate(int) = 0;
};
class Rect :public Shape
{
	int m_left, m_right, m_top, m_bottom;
public:
	Rect(int = 0, int = 0, int = 0, int = 0, color = BLACK);
	//void GetRect(int, int, int, int, color);
	//void SetRect(int, int, int, int, color);
	void WhereAmI() const;
	virtual ~Rect() ;
	virtual void WhereAmI_Virtual() const;
	virtual void Inflate(int);
	void Get(int, int, int, int);
};
class Circle :public Shape
{
	int m_center_x, m_center_y, m_rad;
public:
	Circle(int = 0, int = 0, int = 0, color = BLACK);
	Circle(Rect&);
	//void GetCircle(int, int, int, int, color);
	//void SetCircle(int, int, int, int, color);
	void WhereAmI() const;
	virtual ~Circle();
	virtual void WhereAmI_Virtual() const;
	virtual void Inflate(int);
};