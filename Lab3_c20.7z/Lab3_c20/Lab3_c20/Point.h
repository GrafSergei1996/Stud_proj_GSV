#pragma once
class Point
{
	int m_px;
	int m_py;
public:
	Point(int = 0, int = 0);
	Point& operator+= (const Point&);
	Point& operator+= (int);
	void GetPoint(int& , int&) const;
	void SetPoint(int, int);
	Point operator+ (const Point&);
	Point operator+ (const int);
	Point operator+ ();
	Point operator- ();
	Point& operator= (const Point&);
};
Point& operator-= (Point&, const Point&);
Point& operator-= (Point&, const int);
Point operator+ (const int, const Point);
Point operator- (const int, const Point);
Point operator- (const Point, const Point);
Point operator- (const Point, const int);