#pragma once
#include "myString.h"
#include<iostream>
enum Sex { UNDEF, MALE, FEMALE };
class MyData
{
public:

private:
	Sex m_sex;
	size_t m_age;
	MyString m_job;
	float m_salary;
	float m_experience;
public:
	MyData();
	MyData(Sex s, size_t age, const char* job, float sal, size_t exp);
	MyData(const MyData& d);
	MyData& operator=(const MyData& d);
	MyData(MyData&& d);
	MyData& operator=(MyData&& d);
	bool operator == (const MyData& d) const;
	friend std::ostream& operator<<(std::ostream& os, const MyData& d);
};