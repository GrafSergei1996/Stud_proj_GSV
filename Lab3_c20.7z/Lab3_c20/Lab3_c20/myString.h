#pragma once
#include<iostream>
class MyString
{
    char* m_pStr;	//������-���� ������
public:
	MyString(const char* pc1 = nullptr);
	MyString(const MyString&);
	MyString(MyString&&);
	~MyString();
	void SetNewString(const char*);
	void GetString(char*);
	const char* GetString1() const;
	/*void AddString(const char*);*/
	MyString& operator= (const MyString&);
	MyString& operator= (const char*);
	MyString& operator+= (const MyString&);
	MyString operator+ (const const MyString&) const;
	
};
std::ostream& operator<< (std::ostream& out, const MyString&);
MyString AddString(const char*, ...);

