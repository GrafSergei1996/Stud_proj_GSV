#include"MyData.h"
#include <tchar.h>
MyData::MyData()
{
	m_sex = UNDEF;
	m_age = 0;
	m_job = 0;
	m_salary = 0;
	m_experience = 0;
}
MyData::MyData(Sex s, size_t age, const char* job, float sal, size_t exp)
{
	m_sex = s;
	m_age = age;
	m_job = job;
	m_salary = sal;
	m_experience = exp;
}

MyData::MyData(const MyData& d)
{
	m_sex = d.m_sex;
	m_age = d.m_age;
	m_job = d.m_job;
	m_salary = d.m_salary;
	m_experience = d.m_experience;
}

MyData& MyData::operator=(const MyData& d)
{
	m_sex = d.m_sex;
	m_age = d.m_age;
	m_job = d.m_job;
	m_salary = d.m_salary;
	m_experience = d.m_experience;
	return *this;
}

MyData::MyData(MyData&& d)
{
	m_sex = d.m_sex;
	m_age = d.m_age;
	m_job = d.m_job;
	m_salary = d.m_salary;
	m_experience = d.m_experience;
}

MyData& MyData::operator=(MyData&& d)
{
	m_sex = d.m_sex;
	m_age = d.m_age;
	m_job = d.m_job;
	m_salary = d.m_salary;
	m_experience = d.m_experience;
	return *this;
}

bool MyData::operator==(const MyData& d) const
{
	const char* s1 = m_job.GetString1();
	const char* s2 = d.m_job.GetString1();
	if ((m_age == d.m_age) && (m_experience == d.m_experience) && (m_salary == d.m_salary) && (m_sex == d.m_sex) && (strcmp(s1,s2) == 0))
	return true;
}

std::ostream& operator<<(std::ostream& os, const MyData& d)
{
	setlocale(LC_ALL, "Rus");
	switch(d.m_sex)
	{
	case 0:
	{
		os << "���: �� ���������" << '\n';
		break;
	}
	case 1:
	{
		os << "���: �������" << '\n';
		break;
	}
	case 2:
	{
		os << "���: �������" << '\n';
		break;
	}
	}
	os << "�������: " << d.m_age << '\n';
	os << "���������: " << d.m_job << '\n';
	os << "���������� �����: " << d.m_salary << '\n';
	os << "���� ������: " << d.m_experience << '\n';
	return os;
}
