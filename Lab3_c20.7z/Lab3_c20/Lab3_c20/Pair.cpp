#include"Pair.h"
#include<iostream>
#include <tchar.h>
Pair::Pair()
{
	key = 0;
	data = MyData();
}

Pair::Pair(const char* k, const MyData& d)
{
	key = k;
	data = d;
}

Pair::Pair(MyString k, const MyData& d)
{
	key = k;
	data = d;
}

Pair::Pair(const Pair& other)
{
	key = other.key;
	data = other.data;
}

Pair& Pair::operator=(const Pair& other)
{
	key = other.key;
	data = other.data;
	return *this;
}

Pair::Pair(Pair&& other)
{
	key = other.key;
	data = other.data;
}

Pair& Pair::operator=(Pair&& other)
{
	key = other.key;
	data = other.data;
	return *this;
}

bool Pair::operator==(const char* k) const
{
	if (k != nullptr)
	{
		const char* s = key.GetString1();
		if (strcmp(s, k) == 0)
			return true;
		else return false;
	}
	return false;
}

std::ostream& operator<<(std::ostream& os, const Pair& pair)
{
	setlocale(LC_ALL, "Rus");
	os << "���: " << pair.key << '\n' << pair.data;
	return os;
}
