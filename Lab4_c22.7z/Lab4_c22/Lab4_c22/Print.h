#pragma once
#include <memory>
#include <vector>
#include <set>
#include <algorithm>
#include <string>
#include <iostream>
#include <type_traits>
#include <cstdint>
#include<stack>
#include<queue>
using namespace std;
enum class live{yes,no};
class human
{
	string name;
	live zhiv;
	shared_ptr<human> parentM;
	shared_ptr<human> parentF;
	vector<weak_ptr<human>> childs;
	void print1() const;
	void printstar() const;
	void printchild() const;
public:
	human(string,live);
	void sostoyanue(live l);
	human(string, live, shared_ptr<human> mother, shared_ptr<human> father);
	human(const human&) = delete;
	human operator =(const human&) = delete;
	static shared_ptr<human> child(shared_ptr < human>, shared_ptr < human>,string);
	~human();
	void print() const;
};

template<typename T = int, size_t size = 0> class MyArray
{
	T ar[size] {}; //��� ���������� ������������� ��������� �������� ���� �� ��������� �����?
public:
	MyArray();
	~MyArray();
	void print();
	MyArray(const T*);
};

template<typename T,size_t size>  MyArray(const T (&init)[size]) -> MyArray<T, size>;

template <typename T> 
void Prind(const T& t)
{
	using T2 = std::remove_reference_t<decltype(*t.begin())>;
	if constexpr (std::is_pointer_v<T2>)
	{
		for_each(begin(t), end(t), [](const T2& x) {std::cout << *x; });
	}
	else
	{
		for_each(begin(t), end(t), [](const T2& x) {std::cout << x; });
	}
}

template <typename T, typename T1>
void Summ(T& t, const T1& t1)
{
	if constexpr (std::is_same_v<T, std::vector<T1>>)
	{
		for (auto& e : t)
		{
			e = e + t1;
		}
	}
	else
	{
		/*	t += t1;*/

		//if (t.size() < t1.size())
		//{
		//	for (size_t i = 0; i < t.size(); i++)
		//	{
		//		t[i] = t[i] + t1[i];
		//	}
		//	for (size_t i = t.size(); i < t1.size(); i++)
		//	{
		//		t.push_back(t1[i]);
		//	}
		//}
		//else
		//{
		//	for (size_t i = 0; i < t1.size(); i++)
		//	{
		//		t[i] = t[i] + t1[i];
		//	}
		//}
	}
}

template <typename T, typename T1>
void PrindAdap(T& t)
{
	if constexpr (std::is_same_v< T, queue<T1> >)
	{
		for (size_t i = 0; i < size(t)+1; i++)
		{
			std::cout << t.front();
			t.pop();
		}
	}
	else
	{
		for (size_t i = 0; i < size(t)+1; i++)
		{
			std::cout << t.top();
			t.pop();
		}
	}
}

template<typename T, size_t size>
inline MyArray<T, size>::MyArray()
{
	//ar = new T[size];
	for (size_t i = 0; i < size; i++)
	{
		ar[i] = T();
	}
}

template<typename T, size_t size>
inline MyArray<T, size>::~MyArray()
{

}

template<typename T, size_t size>
inline void MyArray<T, size>::print()
{
	for (size_t i = 0; i < size; i++)
	{
		std::cout << ar[i];
	}
}

template<typename T, size_t size>
inline MyArray<T, size>::MyArray(const T* init) 
{
	//size = size(init);
	//ar = new T[size];
	for (size_t i = 0; i < size; i++)
	{
		ar[i] = init[i];
	}
}
