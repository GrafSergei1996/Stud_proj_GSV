#include "Print.h"
using namespace std;
human::human(string s, live l):name(s),zhiv(l),parentM(nullptr),parentF(nullptr)
{

}

void human::sostoyanue(live l)
{
	zhiv = l;
}

human::human(string s, live l, shared_ptr<human> m, shared_ptr<human> f) : name(s), zhiv(l), parentM(m), parentF(f)
{
}

//human::human(const human& h):name(h.name),zhiv(h.zhiv)
//{
//	parentF = h.parentF;
//	parentF = h.parentM;
//}

//human human::operator=(const human& h)
//{
//	for (auto& chi:childs)
//	{
//		chi.~weak_ptr();
//	}
//	for (auto& chi : h.childs)
//	{
//		childs.push_back(chi);
//	}
//	parentF = h.parentF;
//	parentM = h.parentM;
//	return *this;
//}

shared_ptr<human> human::child(shared_ptr <human> human1, shared_ptr < human> human2,string s)
{
	shared_ptr<human> ret = shared_ptr<human>(new human(s, live::yes, human1, human2));
	human1->childs.push_back(std::weak_ptr<human>(ret));
	human2->childs.push_back(std::weak_ptr<human>(ret));
	return ret;
}

void human::print1() const
{
	std::cout << name << '\n';
	if (zhiv == live::yes)
	{
		std::cout << "zhiv" << '\n';
	}
	else
	{
		std::cout << "mertv" << '\n';
	}
}

void human::printstar() const
{
	if ((parentF == nullptr) && (parentM == nullptr))
	{
		//this->print1();
	}
	else
	{
		std::cout << "Roditeli " << this->name << ":\n";
		parentF->print1();
		parentM->print1();
		parentF->printstar();
		parentM->printstar();
	}
}

void human::printchild() const
{
	if (childs.size() != 0)
	{
		std::cout << "Deti " << this->name << ":\n";
		for (auto& chi : childs)
		{
			chi.lock()->print1();
			chi.lock()->printchild();
		}
	}
	else
	{
		//print1();
	}
}

human::~human()
{

}

void human::print() const
{
	this->printstar();
	if (childs.size() != 0)
	{
		for (auto& chi : childs)
		{
			chi.lock()->parentF->print1();
			chi.lock()->parentM->print1();
			break;
			//chi.lock()->print1();
		}
	}
	else
	{
		std::cout << "Imya:\n";
		this->print1();
	}
	this->printchild();
}
