#pragma once
#include<stdexcept>
#include <string>
#include <iostream>
#include <cstdint>
#include <algorithm>
#include <iterator>
#include <memory>
#include<vector>
#include<cmath>
using namespace std;
template <typename T> class Compar
{
	T min;
	T max;
public:
	constexpr Compar(const T& mmin, const T& mmax) :min(mmin), max(mmax) {};
	constexpr const std::vector<T> get() {return std::vector<int> ({ min,max }); };
	constexpr bool InRange(const T& a) { return ((a > min) && (a < max)); };
	constexpr T InRange1(const T& a) { return (a < min) ? (min) : ((a > max) ? (max) : (a)); };
	~Compar() = default;
};


constexpr int len(const char* ch)
{
	return (*ch)? (len(ch+1)+1):(0);
};
constexpr  unsigned int operator "" _b(const char* ch)
{
	return ((*ch) != 0) ? ((((*ch) - '0')<<(len(ch)-1)) + (operator "" _b(ch+1))) : (0);
};

std::string inline operator "" _st(unsigned long long a)
{
	int i = 0;
	unsigned long long a1 = a;
	while (a1 != 0)
	{
		a1 = a1 >> 1;
		++i;
	}
	std::string s(i,'0');
	for (size_t i1 = 0; i1 < i; i1++)
	{
		s[i-i1-1] = ((a >> i1) & 1)+48;
	}
	s.insert(s.begin(), 'b');
	s.insert(s.begin(), '0');
	return s;
}