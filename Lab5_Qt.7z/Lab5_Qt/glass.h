#ifndef GLASS_H
#define GLASS_H

#include <QWidget>
#include<QColor>
#include<QPainter>
#include"figure.h"
#include<QTimer>
#include<QKeyEvent>
#define emptyCell QColor(150,150,150)
class glass : public QWidget
{
    Q_OBJECT
    bool GameOn;
    Figure* curr;
    Figure* next;
    uint score;
    static const uint W = 20;
    uint timeInterval;
    uint m_rows;
    uint m_columns;
    QVector<QVector<QColor>> glassArray;
    uint idtimer;
public:
    explicit glass(QWidget *parent = nullptr);
    void NextFigure();
    void GameOver();
    Q_PROPERTY(uint rows READ rows WRITE setRows);
    Q_PROPERTY(uint columns READ columns WRITE setColumns);
    uint rows() const
    {
        return m_rows;
    }

    uint columns() const
    {
        return m_columns;
    }
    ~glass();

signals:
    void signalGlassInit();
    void signalGameOver();
    void signalNextFigure(Figure*);
    void signalScore(int);
    void signalLabelChanged(QString);
public slots:
    QSize s();
    void slotNewGame();
    void clearGlass();
    void slotGlassInit();
    void setRows(uint rows)
    {
        m_rows = rows;
    }
    void setColumns(uint columns)
    {
        m_columns = columns;
    }

    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);

    // QWidget interface
protected:
    virtual void keyPressEvent(QKeyEvent *event);

    // QObject interface
protected:
    virtual void timerEvent(QTimerEvent *event);
};

#endif // GLASS_H
