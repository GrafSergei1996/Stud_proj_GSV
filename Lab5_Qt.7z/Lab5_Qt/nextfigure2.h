#ifndef NEXTFIGURE2_H
#define NEXTFIGURE2_H

#include <QWidget>
#include "figure.h"
#include<QPainter>
class NextFigure2 : public QWidget
{
    Q_OBJECT
    Figure* next;
    bool IsDraw;
public:
    explicit NextFigure2(QWidget *parent = nullptr);

signals:

public slots:
    void slotNextFigure(Figure*);

    // QWidget interface
protected:
    virtual void paintEvent(QPaintEvent *event);
};

#endif // NEXTFIGURE2_H
