#include "figure.h"

//Figure::Figure()
//{

//}

//Figure::Figure(QVector<QColor> col, uint i, uint j):colors(col),m_i(i),m_j(j)
//{

//}

Figure::Figure(QVector<QColor> col, uint i, uint j, uint W):colors(col),m_i(i),m_j(j),m_W(W)
{

}

void Figure::changeIndex(uint i, uint j, uint limRow, uint limColumn)
{
    if (((m_i>=0) && (i>=0)) || ((m_i <= limRow) && (i <= 0)))
    {
        m_i += i;
    }
    if (((m_j>=0) && (j>=0)) || ((m_j <= limColumn) && (j <= 0)))
    {
        m_j += j;
    }
    if (m_i > 2*limRow)
    {
        m_i = 0;
    }
    if (m_i == limRow)
    {
        m_i = limRow-1;
    }
    if (m_j == limColumn)
    {
        m_j = limColumn-1;
    }

}

void Figure::setIndex(uint i, uint j)
{
    m_i = i;
    m_j = j;
}

//void Figure::changeIndex(uint i, uint j)
//{

//}

void Figure::rotateColors(bool b)
{
    if (b)
    {
        QColor tmp = colors[2];
        colors[2] = colors[1];
        colors[1] = colors[0];
        colors[0] = tmp;
    }
    else
    {
        QColor tmp = colors[0];
        colors[0] = colors[1];
        colors[1] = colors[2];
        colors[2] = tmp;
    }
}

void Figure::makeRandomColors()
{
    QVector<QColor> colorVect(6);
    colorVect[0] = QColor(255,255,0);
    colorVect[1] = QColor(255,0,255);
    colorVect[2] = QColor(0,0,255);
    colorVect[3] = QColor(255,0,0);
    colorVect[4] = QColor(0,255,255);
    colorVect[5] = QColor(0,255,0);
    for (auto& col:colors)
    {
        col = colorVect[QRandomGenerator::global()->generate()%6];
    }
}

void Figure::paintFigure(QPainter painter)
{
//    if (m_j < 2)
//    {

//        for (uint j = m_j; j<-1;j--)
//        {
//            painter.fillRect(m_i*(m_W+1),j*(m_W+1),m_W,m_W,colors[m_j-j]);
//        }
//    }
//    else
//    {
//        for (uint j = 0; j<3;j++)
//        {
//            painter.fillRect(m_i*(m_W+1),m_j-j*(m_W+1),m_W,m_W,colors[j]);
//        }
//    }
}

//void Figure::paintFigure(QPainter painter)
//{

//}

QVector<uint> Figure::getRowColumn()
{
    QVector<uint> res(2);
    res[0] = m_i;
    res[1] = m_j;
    return res;
}

QVector<QColor> Figure::getColor()
{
    return colors;
}
