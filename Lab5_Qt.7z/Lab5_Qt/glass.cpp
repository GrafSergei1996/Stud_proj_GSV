#include "glass.h"
glass::glass(QWidget *parent) : QWidget(parent)
{
    GameOn = 0;
    m_rows = 10;
    m_columns = 20;

    setFocusPolicy(Qt::StrongFocus);
    connect(this,SIGNAL(signalGlassInit()),this,SLOT(slotGlassInit()),Qt::QueuedConnection);
    emit signalGlassInit();
    QVector<QColor> NullColor(3);
    for (auto& col:NullColor)
    {
        col = QColor(150,150,150);
    }
    curr = new Figure(NullColor,0,0,19);
    next = new Figure(NullColor,0,0,19);
}

void glass::NextFigure()
{
    uint sum = 0;
    uint sum1 = 0;
    for (uint j = 0+10;j < m_columns+10;j++)
    {
        for (uint i = 0 ;i < (m_rows-2);i++)
        {
            for (uint i1 = i ;i1 < m_rows;i1++)
            {
                if ((glassArray[i1][j] == glassArray[i][j]) && (glassArray[i][j] != QColor(150,150,150)))
                {
                    ++sum;
                }
                else
                {
                    if (sum <3)
                    {
                       sum = 0;
                    }
                    break;
                }
            }
            if (sum >=3)
            {
                for (uint i1 = i;i1 < (i+sum);i1++)
                {
                    for (uint k = (j); k > 0+10;k--)
                    {
                        glassArray[i1][k] = glassArray[i1][k-1];
                    }
                    glassArray[i1][0+10] = QColor(150,150,150);
                }
                score +=sum;
                sum = 0;
            }
        }
    }

    for (uint i = 0;i < m_rows;i++)
    {
        for (uint j = 0+10 ;j < (m_columns-2)+10;j++)
        {
            for (uint j1 = j ;j1 < m_columns+10;j1++)
            {
                if ((glassArray[i][j1] == glassArray[i][j]) && (glassArray[i][j] != QColor(150,150,150)))
                {
                    ++sum1;
                }
                else
                {
                    if (sum1 < 3)
                    {
                       sum1 = 0;
                    }
                    break;
                }
            }
            if (sum1 >= 3)
            {
                for (uint j1 = j+sum1-1;j1 > (sum1-1)+10;j1--)
                {
                    glassArray[i][j1] = glassArray[i][j1-sum1];
//                    for (uint k = (j); k > 0;k--)
//                    {
//                        glassArray[i1][k] = glassArray[i1][k-1];
//                    }
                }
                for (uint i2 = 0+10;i2 < sum1+10; i2++)
                {
                    glassArray[i][i2] = QColor(150,150,150);
                }
                score += sum1;
                sum1 = 0;
            }
        }
    }
    emit signalScore(score);
}

void glass::GameOver()
{
    GameOn = 0;
    clearGlass();
    emit signalLabelChanged(QStringLiteral("Game over"));
}

glass::~glass()
{
    delete curr;
    delete next;
}

QSize glass::s()
{
    return QSize(W*m_rows,W*(m_columns));
}

void glass::slotNewGame()
{
    GameOn = 1;
    score = 0;
    killTimer(idtimer);
    clearGlass();
    curr->makeRandomColors();
    curr->setIndex(m_rows/2,0);
    next->makeRandomColors();
    //next->changeIndex(0,0,m_rows,m_columns);
    setFocus();
    idtimer = startTimer(500);
    emit signalLabelChanged(QStringLiteral("Score"));
}

void glass::clearGlass()
{
    for (auto& i:glassArray)
    {
        for (auto& j:i)
        {
            j = emptyCell;
        }
    }
}

void glass::slotGlassInit()
{
    glassArray.resize(m_rows);
    for (auto& i:glassArray)
    {
        i.resize(m_columns+10);
    }
    setFixedSize(s());
    clearGlass();
}


void glass::paintEvent(QPaintEvent *event)
{
    QPainter painter(this);
    //clearGlass();
    //glassArray[curr->getRowColumn()[0]][curr->getRowColumn()[1]] =
    if (glassArray.size()>0)
    {
        for (uint x = 0;x<m_rows;x++)
        {
            for (uint y = 0+10; y < m_columns+10;y++)
            {
                //QRectF rect (W,W);
                painter.fillRect(x*W,(y-10)*W,W-1,W-1,glassArray[x][(y)]);
            }
        }
    }
    if ((GameOn == 1) && (glassArray.size()>0))
    {
        for (uint i = 0; i < m_rows;i++)
        {
            int restartInit = 0;
            for (uint j = 0; j <m_columns+10;j++)
            {
                if (glassArray[i][j] != QColor(150,150,150))
                {
                    ++restartInit;
                }
            }
            if (restartInit > m_columns)
            {
                GameOver();
            }
        }
            if (curr->getRowColumn()[1] < 2)
            {
                for (uint j = 0; j < curr->getRowColumn()[1];j++)
                {
                    //glassArray[curr->getRowColumn()[0]][j] = curr->getColor()[curr->getRowColumn()[1]-j];
                    painter.fillRect(curr->getRowColumn()[0]*(19+1),j*(19+1),19,19,curr->getColor()[curr->getRowColumn()[1]-j]);
                }
            }
            else
            {
                for (uint j = 0; j<3;j++)
                {
                    //glassArray[curr->getRowColumn()[0]][curr->getRowColumn()[1]-j] = curr->getColor()[j];
                    painter.fillRect(curr->getRowColumn()[0]*(19+1),(curr->getRowColumn()[1]-j)*(19+1),19,19,curr->getColor()[j]);
                }
            }

            if ((curr->getRowColumn()[1] == (m_columns-1)) || (glassArray[curr->getRowColumn()[0]][curr->getRowColumn()[1]+11] != QColor(150,150,150)))
            {
                for (uint j = 0; j<3;j++)
                {

                        glassArray[curr->getRowColumn()[0]][curr->getRowColumn()[1]-j+10] = curr->getColor()[j];
//                        if ((glassArray[curr->getRowColumn()[0]][curr->getRowColumn()[1]-j+10] != QColor(150,150,150)) && ((curr->getRowColumn()[1]-j+10)<10) )
//                        {
//                            GameOver();
//                        }
                    //painter.fillRect(curr->getRowColumn()[0]*(19+1),(curr->getRowColumn()[1]-j)*(19+1),19,19,curr->getColor()[j]);
                }
                delete curr;
                curr = next;
                QVector<QColor> NullColor(3);
                for (auto& col:NullColor)
                {
                    col = QColor(150,150,150);
                }
                next = new Figure(NullColor,0,0,19);
                next->makeRandomColors();
                curr->setIndex(m_rows/2,0);


            }
            NextFigure();
            //
    }

}


void glass::keyPressEvent(QKeyEvent *event)
{
    if (GameOn)
    {
    //Если«идет игра»

    switch(event->key())
    {//коднажатойклавиши
    case Qt::Key_Left:
    {
        if ((curr->getRowColumn()[0]-1) >= 0)
        {
            if (glassArray[curr->getRowColumn()[0]-1][curr->getRowColumn()[1]+10] == QColor(150,150,150))
            {
                curr->changeIndex(-1,0,m_rows,m_columns);//если есть «куда», перемещаем фигурку влево
                this->repaint();
            }
        }
        break;
    }

    case Qt::Key_Right:
    {
        if ((curr->getRowColumn()[0]+1) <= 9)
        {
            if (glassArray[curr->getRowColumn()[0]+1][curr->getRowColumn()[1]+10] == QColor(150,150,150))
            {
                curr->changeIndex(1,0,m_rows,m_columns);
                this->repaint();
            }
        }
        break;
    }

    case Qt::Key_Down:
    {
        curr->rotateColors(true);
        this->repaint();
        break;
    }

    case Qt::Key_Up:
    {
        curr->rotateColors(false);
        this->repaint();
        break;
    }

    case Qt::Key_Space:
    {
        curr->changeIndex(0,1,m_rows,m_columns);
        this->repaint();
        break;
    }

    default:
    {
            QWidget::keyPressEvent(event);
    }
 //принажатиилюбыхдругихклавишвызываембазовуюобработкусобытия
    }
    }
    else
    {
    QWidget::keyPressEvent(event);//
    }
}


void glass::timerEvent(QTimerEvent *event)
{

        curr->changeIndex(0,1,m_rows,m_columns);
        emit signalNextFigure(next);
        this->repaint();


}
