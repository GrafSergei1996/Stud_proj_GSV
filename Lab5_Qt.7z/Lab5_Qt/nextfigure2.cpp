#include "nextfigure2.h"

NextFigure2::NextFigure2(QWidget *parent) : QWidget(parent)
{

}

void NextFigure2::slotNextFigure(Figure *fig)
{
    //delete next;
    next = fig;
    IsDraw = 1;
    repaint();
}


void NextFigure2::paintEvent(QPaintEvent *event)
{
    if (IsDraw == 1)
    {
        QPainter painter(this);
        painter.translate(QPointF(this->width()/2,0));
        for (uint i =0;i < 3; i++)
        {
           painter.fillRect(0,i*20,19,19,next->getColor()[2-i]);
        }
        IsDraw = 0;
    }
}
