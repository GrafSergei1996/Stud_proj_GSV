#ifndef FIGURE_H
#define FIGURE_H
#include<QColor>
#include<QVector>
#include<QPainter>
#include<QRandomGenerator>
class Figure
{
    QVector<QColor> colors;
    uint m_i;
    uint m_j;
    uint m_W;

public:
    //Figure();
    explicit Figure(QVector<QColor>,uint,uint,uint);
    void changeIndex(uint,uint,uint,uint);
    void setIndex(uint,uint);
    void rotateColors(bool);
    void makeRandomColors();
    void paintFigure(QPainter);
    QVector<uint> getRowColumn();
    QVector<QColor> getColor();
    //~Figure();
};

#endif // FIGURE_H
