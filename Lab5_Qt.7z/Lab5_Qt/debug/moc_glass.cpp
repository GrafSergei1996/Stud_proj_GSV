/****************************************************************************
** Meta object code from reading C++ file 'glass.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.1)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../glass.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'glass.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.1. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_glass_t {
    QByteArrayData data[16];
    char stringdata0[165];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_glass_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_glass_t qt_meta_stringdata_glass = {
    {
QT_MOC_LITERAL(0, 0, 5), // "glass"
QT_MOC_LITERAL(1, 6, 15), // "signalGlassInit"
QT_MOC_LITERAL(2, 22, 0), // ""
QT_MOC_LITERAL(3, 23, 14), // "signalGameOver"
QT_MOC_LITERAL(4, 38, 16), // "signalNextFigure"
QT_MOC_LITERAL(5, 55, 7), // "Figure*"
QT_MOC_LITERAL(6, 63, 11), // "signalScore"
QT_MOC_LITERAL(7, 75, 18), // "signalLabelChanged"
QT_MOC_LITERAL(8, 94, 1), // "s"
QT_MOC_LITERAL(9, 96, 11), // "slotNewGame"
QT_MOC_LITERAL(10, 108, 10), // "clearGlass"
QT_MOC_LITERAL(11, 119, 13), // "slotGlassInit"
QT_MOC_LITERAL(12, 133, 7), // "setRows"
QT_MOC_LITERAL(13, 141, 4), // "rows"
QT_MOC_LITERAL(14, 146, 10), // "setColumns"
QT_MOC_LITERAL(15, 157, 7) // "columns"

    },
    "glass\0signalGlassInit\0\0signalGameOver\0"
    "signalNextFigure\0Figure*\0signalScore\0"
    "signalLabelChanged\0s\0slotNewGame\0"
    "clearGlass\0slotGlassInit\0setRows\0rows\0"
    "setColumns\0columns"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_glass[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      11,   14, // methods
       2,   90, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       5,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,   69,    2, 0x06 /* Public */,
       3,    0,   70,    2, 0x06 /* Public */,
       4,    1,   71,    2, 0x06 /* Public */,
       6,    1,   74,    2, 0x06 /* Public */,
       7,    1,   77,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       8,    0,   80,    2, 0x0a /* Public */,
       9,    0,   81,    2, 0x0a /* Public */,
      10,    0,   82,    2, 0x0a /* Public */,
      11,    0,   83,    2, 0x0a /* Public */,
      12,    1,   84,    2, 0x0a /* Public */,
      14,    1,   87,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 5,    2,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString,    2,

 // slots: parameters
    QMetaType::QSize,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UInt,   13,
    QMetaType::Void, QMetaType::UInt,   15,

 // properties: name, type, flags
      13, QMetaType::UInt, 0x00095103,
      15, QMetaType::UInt, 0x00095103,

       0        // eod
};

void glass::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<glass *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->signalGlassInit(); break;
        case 1: _t->signalGameOver(); break;
        case 2: _t->signalNextFigure((*reinterpret_cast< Figure*(*)>(_a[1]))); break;
        case 3: _t->signalScore((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 4: _t->signalLabelChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: { QSize _r = _t->s();
            if (_a[0]) *reinterpret_cast< QSize*>(_a[0]) = std::move(_r); }  break;
        case 6: _t->slotNewGame(); break;
        case 7: _t->clearGlass(); break;
        case 8: _t->slotGlassInit(); break;
        case 9: _t->setRows((*reinterpret_cast< uint(*)>(_a[1]))); break;
        case 10: _t->setColumns((*reinterpret_cast< uint(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (glass::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&glass::signalGlassInit)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (glass::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&glass::signalGameOver)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (glass::*)(Figure * );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&glass::signalNextFigure)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (glass::*)(int );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&glass::signalScore)) {
                *result = 3;
                return;
            }
        }
        {
            using _t = void (glass::*)(QString );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&glass::signalLabelChanged)) {
                *result = 4;
                return;
            }
        }
    }
#ifndef QT_NO_PROPERTIES
    else if (_c == QMetaObject::ReadProperty) {
        auto *_t = static_cast<glass *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< uint*>(_v) = _t->rows(); break;
        case 1: *reinterpret_cast< uint*>(_v) = _t->columns(); break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = static_cast<glass *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: _t->setRows(*reinterpret_cast< uint*>(_v)); break;
        case 1: _t->setColumns(*reinterpret_cast< uint*>(_v)); break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
}

QT_INIT_METAOBJECT const QMetaObject glass::staticMetaObject = { {
    &QWidget::staticMetaObject,
    qt_meta_stringdata_glass.data,
    qt_meta_data_glass,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *glass::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *glass::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_glass.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int glass::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 11)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 11;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 11)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 11;
    }
#ifndef QT_NO_PROPERTIES
   else if (_c == QMetaObject::ReadProperty || _c == QMetaObject::WriteProperty
            || _c == QMetaObject::ResetProperty || _c == QMetaObject::RegisterPropertyMetaType) {
        qt_static_metacall(this, _c, _id, _a);
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyDesignable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyScriptable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyStored) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyEditable) {
        _id -= 2;
    } else if (_c == QMetaObject::QueryPropertyUser) {
        _id -= 2;
    }
#endif // QT_NO_PROPERTIES
    return _id;
}

// SIGNAL 0
void glass::signalGlassInit()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void glass::signalGameOver()
{
    QMetaObject::activate(this, &staticMetaObject, 1, nullptr);
}

// SIGNAL 2
void glass::signalNextFigure(Figure * _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void glass::signalScore(int _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void glass::signalLabelChanged(QString _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
